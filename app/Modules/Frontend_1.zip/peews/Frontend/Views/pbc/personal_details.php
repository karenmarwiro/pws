<?php $this->extend('App\Modules\Frontend\Views\Layouts\default') ?>

<?= $this->section('title') ?>Applicant Details - PBC Registration<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<?= module_css('pbc/apply.css') ?>
<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f8f9fa;
        color: #333;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="personal-details-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <!-- Registration Header -->
                <div class="registration-header">
                    <h1>Private Business Corporation Registration</h1>
                    <p>Step 1 of 4: Applicant Personal Details</p>
                </div>
                
                <!-- Progress Steps -->
                <div class="registration-steps">
                    <div class="step active">
                        <div class="step-number">1</div>
                        <div class="step-label">Personal Details</div>
                    </div>
                    <div class="step">
                        <div class="step-number">2</div>
                        <div class="step-label">Business Details</div>
                    </div>
                    <div class="step">
                        <div class="step-number">3</div>
                        <div class="step-label">Directors & Shareholders</div>
                    </div>
                    <div class="step">
                        <div class="step-number">4</div>
                        <div class="step-label">Review & Submit</div>
                    </div>
                </div>
                
                <!-- Main Form -->
                <form id="personalDetailsForm" class="registration-form">
                    <!-- Personal Information Section -->
                    <div class="form-section">
                        <h3>Personal Information</h3>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="firstName" class="form-label">First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="firstName" name="firstName" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="lastName" class="form-label">Last Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="lastName" name="lastName" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="idNumber" class="form-label">ID Number/Passport <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="idNumber" name="idNumber" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="dateOfBirth" class="form-label">Date of Birth <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="dateOfBirth" name="dateOfBirth" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" id="phone" name="phone" required>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Address Information Section -->
                    <div class="form-section">
                        <h3>Residential Address</h3>
                        <div class="row">
                            <div class="col-12 mb-3">
                                <label for="streetAddress" class="form-label">Street Address <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="streetAddress" name="streetAddress" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="city" class="form-label">City/Town <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="city" name="city" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="province" class="form-label">Province <span class="text-danger">*</span></label>
                                <select class="form-select" id="province" name="province" required>
                                    <option value="" selected disabled>Select Province</option>
                                    <option value="Harare">Harare</option>
                                    <option value="Bulawayo">Bulawayo</option>
                                    <option value="Manicaland">Manicaland</option>
                                    <option value="Mashonaland Central">Mashonaland Central</option>
                                    <option value="Mashonaland East">Mashonaland East</option>
                                    <option value="Mashonaland West">Mashonaland West</option>
                                    <option value="Masvingo">Masvingo</option>
                                    <option value="Matabeleland North">Matabeleland North</option>
                                    <option value="Matabeleland South">Matabeleland South</option>
                                    <option value="Midlands">Midlands</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="postalCode" class="form-label">Postal Code <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="postalCode" name="postalCode" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="country" class="form-label">Country <span class="text-danger">*</span></label>
                                <select class="form-select" id="country" name="country" required>
                                    <option value="Zimbabwe" selected>Zimbabwe</option>
                                    <!-- Add other countries if needed -->
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Document Upload Section -->
                    <div class="form-section">
                        <h3>Document Upload</h3>
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label class="form-label d-block">ID/Passport Copy (Front) <span class="text-danger">*</span></label>
                                <div class="file-upload" id="idFrontUpload">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                    <p>Click to upload or drag and drop</p>
                                    <p class="small text-muted mb-0">JPG, PNG or PDF (max. 5MB)</p>
                                    <input type="file" id="idFront" name="idFront" accept=".jpg,.jpeg,.png,.pdf" required>
                                </div>
                                <div id="idFrontPreview" class="d-none mt-2">
                                    <span class="badge bg-success">File uploaded</span>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label class="form-label d-block">ID/Passport Copy (Back) <span class="text-danger">*</span></label>
                                <div class="file-upload" id="idBackUpload">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                    <p>Click to upload or drag and drop</p>
                                    <p class="small text-muted mb-0">JPG, PNG or PDF (max. 5MB)</p>
                                    <input type="file" id="idBack" name="idBack" accept=".jpg,.jpeg,.png,.pdf" required>
                                </div>
                                <div id="idBackPreview" class="d-none mt-2">
                                    <span class="badge bg-success">File uploaded</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label d-block">Proof of Residence <span class="text-danger">*</span></label>
                                <div class="file-upload" id="proofOfResidenceUpload">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                    <p>Click to upload or drag and drop</p>
                                    <p class="small text-muted mb-0">JPG, PNG or PDF (max. 5MB)</p>
                                    <input type="file" id="proofOfResidence" name="proofOfResidence" accept=".jpg,.jpeg,.png,.pdf" required>
                                </div>
                                <div id="proofOfResidencePreview" class="d-none mt-2">
                                    <span class="badge bg-success">File uploaded</span>
                                </div>
                                <div class="form-text">Utility bill or bank statement not older than 3 months</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Form Navigation -->
                    <div class="form-navigation">
                        <a href="<?= site_url('pbc/apply') ?>" class="btn btn-prev">
                            <i class="fas fa-arrow-left me-2"></i>Back
                        </a>
                        <button type="submit" class="btn btn-next">
                            Save & Continue<i class="fas fa-arrow-right ms-2"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // File Upload Handling
    function setupFileUpload(uploadElementId, previewElementId) {
        const uploadElement = document.getElementById(uploadElementId);
        const fileInput = uploadElement.querySelector('input[type="file"]');
        const previewElement = document.getElementById(previewElementId);
        
        uploadElement.addEventListener('click', function(e) {
            if (e.target !== fileInput) {
                fileInput.click();
            }
        });
        
        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                previewElement.classList.remove('d-none');
                uploadElement.style.borderColor = '#10b981';
            } else {
                previewElement.classList.add('d-none');
                uploadElement.style.borderColor = '#e2e8f0';
            }
        });
        
        // Drag and drop functionality
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadElement.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        ['dragenter', 'dragover'].forEach(eventName => {
            uploadElement.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            uploadElement.addEventListener(eventName, unhighlight, false);
        });
        
        function highlight() {
            uploadElement.style.borderColor = '#2563eb';
            uploadElement.style.backgroundColor = 'rgba(37, 99, 235, 0.05)';
        }
        
        function unhighlight() {
            uploadElement.style.borderColor = fileInput.files.length ? '#10b981' : '#e2e8f0';
            uploadElement.style.backgroundColor = '';
        }
        
        uploadElement.addEventListener('drop', handleDrop, false);
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            fileInput.files = files;
            
            // Trigger change event
            const event = new Event('change');
            fileInput.dispatchEvent(event);
        }
    }
    
    // Initialize file uploads
    setupFileUpload('idFrontUpload', 'idFrontPreview');
    setupFileUpload('idBackUpload', 'idBackPreview');
    setupFileUpload('proofOfResidenceUpload', 'proofOfResidencePreview');
    
    // Form Validation
    const form = document.getElementById('personalDetailsForm');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Basic validation
            let isValid = true;
            const requiredFields = form.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            if (isValid) {
                // Form is valid, proceed to next step
                window.location.href = '<?= site_url('pbc/business-details') ?>';
            } else {
                // Scroll to first invalid field
                const firstInvalid = form.querySelector('.is-invalid');
                if (firstInvalid) {
                    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstInvalid.focus();
                }
            }
        });
    }
});
</script>
<?= $this->endSection() ?>
