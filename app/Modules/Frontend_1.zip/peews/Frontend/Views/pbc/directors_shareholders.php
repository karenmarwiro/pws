<?php $this->extend('App\Modules\Frontend\Views\Layouts\default') ?>

<?= $this->section('title') ?>Directors & Shareholders - PBC Registration<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<link href="<?= base_url('assets/css/pbc/apply.css') ?>" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }
        
        .form-control, .btn {
            border-radius: 8px;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(106, 17, 203, 0.1);
            border-color: #6a11cb;
        }
        
        .shareholder-card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid #e9ecef;
            position: relative;
        }
        
        .shareholder-number {
            position: absolute;
            top: -10px;
            left: 20px;
            background: #6a11cb;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 0.9rem;
        }
        
        .remove-shareholder {
            position: absolute;
            top: 10px;
            right: 15px;
            color: #dc3545;
            background: none;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
            opacity: 0.7;
            transition: opacity 0.3s;
        }
        
        .remove-shareholder:hover {
            opacity: 1;
        }
        
        .add-shareholder-btn {
            background: #f8f9fa;
            border: 2px dashed #dee2e6;
            color: #6c757d;
            padding: 1.5rem;
            text-align: center;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 1.5rem;
        }
        
        .add-shareholder-btn:hover {
            border-color: #6a11cb;
            color: #6a11cb;
            background: #f0e6ff;
        }
        
        .total-shares {
            font-size: 1.1rem;
            font-weight: 600;
            margin: 1.5rem 0;
            padding: 1rem;
            background: #e9ecef;
            border-radius: 8px;
            text-align: center;
        }
        
        .total-valid {
            background: #d4edda;
            color: #155724;
        }
        
        .total-invalid {
            background: #f8d7da;
            color: #721c24;
        }
    </style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <!-- Registration Header -->
            <div class="text-center mb-5">
                <h1 class="display-5 fw-bold text-gradient text-primary mb-3">Company Registration</h1>
                <p class="lead text-muted">Step 3 of 4: Directors & Shareholders Information</p>
                
                <!-- Progress Steps -->
                <div class="progress-wrapper my-4">
                    <div class="progress-steps d-flex justify-content-between position-relative">
                        <div class="step completed">
                            <div class="step-number">1</div>
                            <div class="step-label d-none d-md-block">Personal Details</div>
                        </div>
                        <div class="step completed">
                            <div class="step-number">2</div>
                            <div class="step-label d-none d-md-block">Company Details</div>
                        </div>
                        <div class="step active">
                            <div class="step-number">3</div>
                            <div class="step-label d-none d-md-block">Directors & Shareholders</div>
                        </div>
                        <div class="step">
                            <div class="step-number">4</div>
                            <div class="step-label d-none d-md-block">Review & Submit</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card shadow-sm mb-4">
                <div class="card-body p-4">
                    <form action="<?= site_url('frontend/pbc/process-shareholders') ?>" method="post" id="shareholdersForm">
                        <?= csrf_field() ?>
                    <div class="card-header text-center">
                        <h4><i class="fas fa-users me-2"></i> Directors & Shareholders</h4>
                        <p class="mb-0">Step 3 of 4 - Add company directors and shareholders</p>
                    </div>
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?= session('error') ?>
                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?= session('message') ?>
                        </div>
                    <?php endif; ?>

                    <div id="shareholdersContainer">
                        <!-- Shareholder cards will be added here dynamically -->
                    </div>

                    <div class="add-shareholder-btn" id="addShareholderBtn">
                        <i class="fas fa-plus-circle fa-2x mb-2"></i>
                        <p class="mb-0">Add Shareholder/Director</p>
                    </div>

                    <div class="total-shares" id="totalShares">
                        Total Shareholding: <span id="sharesSum">0</span>%
                    </div>

                    <!-- Form Actions -->
                    <div class="d-flex justify-content-between mt-5 pt-3 border-top">
                        <a href="<?= site_url('frontend/pbc/business-details') ?>" class="btn btn-outline-secondary px-4">
                            <i class="fas fa-arrow-left me-2"></i> Back
                        </a>
                        <button type="submit" class="btn btn-primary px-4">
                            Save & Continue <i class="fas fa-arrow-right ms-2"></i>
                        </button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Shareholder Template (hidden) -->
<template id="shareholderTemplate">
    <div class="shareholder-card" data-shareholder-index="0">
        <div class="shareholder-number">1</div>
        <button type="button" class="remove-shareholder" title="Remove shareholder">
            <i class="fas fa-times"></i>
        </button>
        <div class="row g-3">

            <!-- Full Name -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Full Name <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" class="form-control shareholder-name"
                               name="shareholders[0][full_name]" required 
                               placeholder="Enter full name">
                    </div>
                </div>
            </div>

            <!-- National ID -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">National ID/Passport No <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                        <input type="text" class="form-control shareholder-id"
                               name="shareholders[0][national_id]" required 
                               placeholder="Enter ID/Passport number">
                    </div>
                </div>
            </div>

            <!-- Nationality -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Nationality <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-flag"></i></span>
                        <input type="text" class="form-control shareholder-nationality"
                               name="shareholders[0][nationality]" required 
                               placeholder="Enter nationality">
                    </div>
                </div>
            </div>

            <!-- Shareholding -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Shareholding (%) <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-percentage"></i></span>
                        <input type="number" class="form-control shareholder-percent"
                               name="shareholders[0][shareholding]" min="1" max="100" step="0.01" 
                               required placeholder="e.g. 50">
                    </div>
                </div>
            </div>

            <!-- Email -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Email Address <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                        <input type="email" class="form-control shareholder-email"
                               name="shareholders[0][email]" required 
                               placeholder="email@example.com">
                    </div>
                </div>
            </div>

            <!-- Phone -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-phone"></i></span>
                        <input type="tel" class="form-control shareholder-phone"
                               name="shareholders[0][phone_number]" 
                               placeholder="(123) 456-7890">
                    </div>
                </div>
            </div>

            <!-- Gender -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Gender <span class="text-danger">*</span></label>
                    <select class="form-control" name="shareholders[0][gender]" required>
                        <option value="">Select gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>

            <!-- Date of Birth -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Date of Birth <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" name="shareholders[0][date_of_birth]" required>
                </div>
            </div>

            <!-- Residential Address -->
            <div class="col-md-12">
                <div class="form-group">
                    <label class="form-label">Residential Address <span class="text-danger">*</span></label>
                    <textarea class="form-control" name="shareholders[0][residential_address]" required
                              placeholder="Enter residential address"></textarea>
                </div>
            </div>

            <!-- Marital Status -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Marital Status</label>
                    <select class="form-control" name="shareholders[0][marital_status]">
                        <option value="">Select status</option>
                        <option value="Single">Single</option>
                        <option value="Married">Married</option>
                        <option value="Divorced">Divorced</option>
                        <option value="Widowed">Widowed</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>

            <!-- City -->
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">City</label>
                    <input type="text" class="form-control" name="shareholders[0][city]" placeholder="Enter city">
                </div>
            </div>

            <!-- Beneficial Owner -->
            <div class="col-md-6">
                <div class="form-check mt-4">
                    <input class="form-check-input" type="checkbox" name="shareholders[0][is_beneficial_owner]" value="1">
                    <label class="form-check-label">Is Beneficial Owner</label>
                </div>
            </div>

            <!-- Documents -->
            <div class="col-md-6">
                <div class="form-group">
                    <label>ID Document</label>
                    <input type="file" class="form-control" name="shareholders[0][id_document]">
                </div>
                <div class="form-group">
                    <label>Proof of Residence</label>
                    <input type="file" class="form-control" name="shareholders[0][proof_of_residence]">
                </div>
                <div class="form-group">
                    <label>Passport Photo</label>
                    <input type="file" class="form-control" name="shareholders[0][passport_photo]">
                </div>
                <div class="form-group">
                    <label>Proof of Address</label>
                    <input type="file" class="form-control" name="shareholders[0][proof_of_address]">
                </div>
                <div class="form-group">
                    <label>Share Certificate</label>
                    <input type="file" class="form-control" name="shareholders[0][share_certificate]">
                </div>
                <div class="form-group">
                    <label>Company Registration Document</label>
                    <input type="file" class="form-control" name="shareholders[0][company_registration_doc]">
                </div>
            </div>

            <!-- Director checkbox -->
            <div class="col-12">
                <div class="form-check mt-3">
                    <input class="form-check-input" type="checkbox" id="isDirector0" 
                           name="shareholders[0][is_director]" value="1" checked>
                    <label class="form-check-label" for="isDirector0">
                        This person is also a director
                    </label>
                </div>
            </div>

        </div>
    </div>
</template>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('shareholdersContainer');
    const addBtn = document.getElementById('addShareholderBtn');
    const sharesSumSpan = document.getElementById('sharesSum');
    const template = document.getElementById('shareholderTemplate');

    let shareholderCount = 0;

    // Add first shareholder by default
    addShareholder();

    function addShareholder() {
        const newShareholder = template.content.cloneNode(true);
        const newIndex = shareholderCount;

        const card = newShareholder.querySelector('.shareholder-card');
        card.dataset.shareholderIndex = newIndex;
        card.querySelector('.shareholder-number').textContent = newIndex + 1;

        const inputs = newShareholder.querySelectorAll('input, label[for]');
        inputs.forEach(input => {
            if (input.id) input.id = input.id.replace('0', newIndex);
            if (input.name) input.name = input.name.replace('[0]', `[${newIndex}]`);
            if (input.htmlFor) input.htmlFor = input.htmlFor.replace('0', newIndex);
        });

        // Remove shareholder button
        card.querySelector('.remove-shareholder').addEventListener('click', function() {
            if (shareholderCount > 1) {
                card.remove();
                shareholderCount--;
                updateShareholderNumbers();
                updateTotalShares();
            } else {
                alert('At least one shareholder is required');
            }
        });

        container.appendChild(card);
        shareholderCount++;
        updateShareholderNumbers();
        updateTotalShares();
    }

    function updateShareholderNumbers() {
        container.querySelectorAll('.shareholder-card').forEach((card, index) => {
            card.querySelector('.shareholder-number').textContent = index + 1;
        });
    }

    function updateTotalShares() {
        let total = 0;
        container.querySelectorAll('.shareholder-percent').forEach(input => {
            total += parseFloat(input.value) || 0;
        });
        sharesSumSpan.textContent = total.toFixed(2);
    }

    addBtn.addEventListener('click', addShareholder);
});
</script>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Shareholder management logic will go here
    });
</script>
<?= $this->endSection() ?>
