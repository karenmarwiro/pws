<?php $this->extend('App\Modules\Frontend\Views\Layouts\default') ?>

<?= $this->section('title') ?>Company Details - PBC Registration<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<link href="<?= base_url('assets/css/pbc/apply.css') ?>" rel="stylesheet">
<style>
    :root {
        --primary: #4361ee;
        --primary-light: #eef2ff;
        --secondary: #3f37c9;
        --dark: #1e293b;
        --light: #f8fafc;
        --gray: #64748b;
        --light-gray: #f1f5f9;
        --border-radius: 12px;
        --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }

    .text-gradient {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* Progress Steps */
    .progress-wrapper {
        max-width: 800px;
        margin: 0 auto;
    }

    .progress-steps .step-indicator {
        text-align: center;
        flex: 1;
        position: relative;
    }

    .step-indicator .step-dot {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background-color: #e2e8f0;
        color: #94a3b8;
        font-weight: 600;
        font-size: 0.875rem;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        transition: all 0.3s ease;
    }

    .step-indicator.completed .step-dot {
        background-color: var(--primary);
        color: white;
    }

    .step-indicator.active .step-dot {
        background-color: var(--primary);
        color: white;
        transform: scale(1.1);
        box-shadow: 0 0 0 4px var(--primary-light);
    }

    .step-label {
        color: var(--gray);
        font-size: 0.75rem;
        font-weight: 500;
        margin-top: 0.5rem;
        transition: all 0.3s ease;
    }

    .step-indicator.active .step-label,
    .step-indicator.completed .step-label {
        color: var(--dark);
        font-weight: 600;
    }

    /* Form Styles */
    .form-section {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 2rem;
        margin-bottom: 2rem;
        box-shadow: var(--shadow);
        border: 1px solid #e2e8f0;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .form-section:hover {
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
        transform: translateY(-2px);
    }

    .form-section h3 {
        color: var(--dark);
        font-size: 1.25rem;
        font-weight: 600;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .form-section h3 i {
        color: var(--primary);
        font-size: 1.1em;
    }

    .form-label {
        font-weight: 500;
        color: var(--dark);
        margin-bottom: 0.5rem;
        font-size: 0.875rem;
        transition: color 0.2s ease;
    }
    
    .company-name-item:hover .form-label {
        color: var(--primary);
    }
    
    .company-name-item {
        position: relative;
        padding: 1.5rem;
        background: #f8fafc;
        border-radius: 8px;
        transition: all 0.3s ease;
    }
    
    .company-name-item:hover {
        background: #f1f5ff;
    }
    
    .company-name-item .input-group-text {
        background: #fff;
        border-right: none;
    }
    
    .company-name-item .form-control {
        border-left: none;
        padding-left: 0;
        background: #fff;
    }
    
    .company-name-item .form-control:focus {
        border-color: #ced4da;
        box-shadow: none;
    }
    
    .company-name-item .form-control:focus + .input-group-text {
        border-color: var(--primary);
    }
    
    .clear-name {
        opacity: 0;
        transition: opacity 0.2s ease;
    }
    
    .company-name-item:hover .clear-name {
        opacity: 1;
    }
    
    .company-number {
        font-weight: 600;
        font-size: 0.8rem;
    }
    
    .bg-primary-soft {
        background-color: rgba(67, 97, 238, 0.1) !important;
    }

    .form-control, .form-select {
        padding: 0.75rem 1rem;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        font-size: 0.9375rem;
        transition: all 0.3s ease;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-light);
    }

    .input-group-text {
        background-color: var(--light);
        border: 1px solid #e2e8f0;
        color: var(--gray);
    }

    /* Buttons */
    .btn {
        font-weight: 500;
        padding: 0.75rem 1.5rem;
        border-radius: 8px;
        transition: all 0.3s ease;
    }

    .btn-primary {
        background-color: var(--primary);
        border-color: var(--primary);
    }

    .btn-primary:hover {
        background-color: var(--secondary);
        border-color: var(--secondary);
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(67, 97, 238, 0.2);
    }

    .btn-outline-secondary {
        border-color: #e2e8f0;
        color: var(--gray);
    }

    .btn-outline-secondary:hover {
        background-color: #f8fafc;
        border-color: #cbd5e1;
        color: var(--dark);
    }

    /* File Upload */
    .file-upload {
        border: 2px dashed #cbd5e1;
        border-radius: 8px;
        padding: 2rem 1.5rem;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s ease;
        background-color: #f8fafc;
        position: relative;
        overflow: hidden;
    }

    .file-upload:hover {
        border-color: var(--primary);
        background-color: rgba(67, 97, 238, 0.05);
    }

    .file-upload i {
        font-size: 2rem;
        color: var(--primary);
        margin-bottom: 0.75rem;
        transition: all 0.3s ease;
    }

    .file-upload p {
        margin-bottom: 0.25rem;
        color: var(--gray);
    }

    .file-upload input[type="file"] {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        opacity: 0;
        cursor: pointer;
    }

    .file-upload-hint {
        font-size: 0.75rem;
        color: #94a3b8;
    }

    /* Company Name Suggestions */
    .company-name-suggestions {
        position: absolute;
        width: 100%;
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        margin-top: 5px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        max-height: 200px;
        overflow-y: auto;
        display: none;
    }
    
    .suggestion-item {
        padding: 10px 15px;
        cursor: pointer;
        transition: background 0.2s ease;
    }
    
    .suggestion-item:hover {
        background: #f8f9fa;
    }
    
    .suggestion-item.active {
        background: var(--primary-light);
        color: var(--primary);
    }
    
    /* Responsive Adjustments */
    @media (max-width: 768px) {
        .form-section {
            padding: 1.5rem 1rem;
        }
        
        .progress-steps {
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .step-indicator {
            flex: 0 0 calc(50% - 0.5rem);
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <!-- Registration Header -->
            <div class="text-center mb-5">
                <h1 class="display-5 fw-bold text-gradient text-primary mb-3">Company Registration</h1>
                <p class="lead text-muted">Step 2 of 4: Tell us about your company</p>
                
                <!-- Progress Bar -->
                <div class="progress-wrapper position-relative mt-4">
                    <div class="progress" style="height: 8px;">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <div class="progress-steps d-flex justify-content-between position-absolute w-100" style="top: -10px;">
                        <?php for ($i = 1; $i <= 4; $i++): ?>
                            <div class="step-indicator <?= $i < 2 ? 'completed' : ($i === 2 ? 'active' : '') ?>">
                                <div class="step-dot d-flex align-items-center justify-content-center mx-auto">
                                    <?php if ($i < 2): ?>
                                        <i class="fas fa-check text-white"></i>
                                    <?php else: ?>
                                        <span class="step-number"><?= $i ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="step-label small mt-2">
                                    <?= [
                                        1 => 'Personal',
                                        2 => 'Company',
                                        3 => 'Directors',
                                        4 => 'Review'
                                    ][$i] ?>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
            
            <!-- Main Form -->
            <div class="card shadow-sm mb-4">
                <div class="card-body p-4">
                    <form action="<?= site_url('frontend/pbc/process-company-details') ?>" method="post" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        
                        <!-- Company Names Section -->
                        <div class="form-section">
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <div>
                                    <h3 class="mb-1"><i class="fas fa-signature text-primary me-2"></i>Proposed Company Names</h3>
                                    <p class="text-muted mb-0">Enter up to 4 names in order of preference. We'll check their availability.</p>
                                </div>
                                <div class="badge bg-primary-soft text-primary px-3 py-2">
                                    <i class="fas fa-info-circle me-1"></i> Required
                                </div>
                            </div>

                            <div class="company-names-container">
                                <?php for ($i = 1; $i <= 4; $i++): ?>
                                <div class="company-name-item <?= $i > 1 ? 'mt-4' : '' ?>">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="company-number bg-primary-soft text-primary d-flex align-items-center justify-content-center rounded-circle me-3" style="width: 28px; height: 28px;">
                                            <?= $i ?>
                                        </div>
                                        <label for="name<?= $i ?>" class="form-label fw-semibold mb-0">
                                            Company Name <?= $i ?> <span class="text-danger">*</span>
                                        </label>
                                    </div>
                                    <div class="input-group input-group-lg">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class="fas fa-building text-muted"></i>
                                        </span>
                                        <input type="text" 
                                               class="form-control form-control-lg" 
                                               id="name<?= $i ?>" 
                                               name="name<?= $i ?>" 
                                               required
                                               placeholder="e.g. <?= [
                                                   1 => 'Global Innovations (Private) Limited',
                                                   2 => 'TechPioneer Solutions (Pvt) Ltd',
                                                   3 => 'Prime Business Ventures (Private) Limited',
                                                   4 => 'Summit Enterprises (Pvt) Ltd'
                                               ][$i] ?>"
                                               data-parsley-trigger="change"
                                               data-parsley-minlength="3"
                                               data-parsley-maxlength="120">
                                        <button type="button" class="btn btn-outline-secondary border-start-0 clear-name" data-target="name<?= $i ?>">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                    <div class="form-text text-muted small mt-1 ps-4">
                                        Include 'Private Limited' or '(Pvt) Ltd' at the end of your company name
                                    </div>
                                </div>
                                <?php endfor; ?>
                            </div>

                            <div class="alert alert-light mt-4" role="alert">
                                <div class="d-flex">
                                    <div class="flex-shrink-0 me-3">
                                        <i class="fas fa-lightbulb text-warning"></i>
                                    </div>
                                    <div>
                                        <h6 class="alert-heading mb-2">Naming Guidelines</h6>
                                        <ul class="small mb-0">
                                            <li>Must be unique and not similar to existing registered companies</li>
                                            <li>Should end with 'Private Limited' or '(Pvt) Ltd'</li>
                                            <li>Avoid using restricted words without proper authorization</li>
                                            <li>No offensive or misleading names allowed</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Company Details Section -->
                        <div class="form-section">
                            <h3><i class="fas fa-building text-primary me-2"></i>Company Information</h3>
                            
                            <div class="row g-3">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="physical_address" class="form-label">Physical Address <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                                            <input type="text" class="form-control" id="physical_address" 
                                                   name="physical_address" required
                                                   placeholder="Enter physical address">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="suburb_city" class="form-label">Suburb & City <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-city"></i></span>
                                            <input type="text" class="form-control" id="suburb_city" 
                                                   name="suburb_city" required
                                                   placeholder="Enter suburb and city">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="postal_code" class="form-label">Postal Code <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                            <input type="text" class="form-control" id="postal_code" 
                                                   name="postal_code" required
                                                   placeholder="Enter postal code">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="country" class="form-label">Country <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-flag"></i></span>
                                            <select class="form-select" id="country" name="country" required>
                                                <option value="">Select Country</option>
                                                <option value="Zimbabwe" selected>Zimbabwe</option>
                                                <option value="South Africa">South Africa</option>
                                                <option value="Botswana">Botswana</option>
                                                <option value="Zambia">Zambia</option>
                                                <option value="Mozambique">Mozambique</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="phone_number" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                            <input type="tel" class="form-control" id="phone_number" 
                                                   name="phone_number" required
                                                   placeholder="Enter phone number">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                            <input type="email" class="form-control" id="email" 
                                                   name="email" required
                                                   placeholder="Enter email">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="website" class="form-label">Website</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-globe"></i></span>
                                            <input type="url" class="form-control" id="website" 
                                                   name="website"
                                                   placeholder="Enter website (optional)">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="business_type" class="form-label">Main Type of Business <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-briefcase"></i></span>
                                            <input type="text" class="form-control" id="business_type" 
                                                   name="business_type" required
                                                   placeholder="e.g., IT Services, Retail, Consulting">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="year_end" class="form-label">Financial Year End <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                            <input type="date" class="form-control" id="year_end" 
                                                   name="year_end" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Form Actions -->
                        <div class="d-flex justify-content-between mt-5 pt-3 border-top">
                            <a href="<?= site_url('frontend/pbc/personal-details') ?>" class="btn btn-outline-secondary px-4">
                                <i class="fas fa-arrow-left me-2"></i>Back to Personal Details
                            </a>
                            <button type="submit" class="btn btn-primary px-4">
                                Save & Continue <i class="fas fa-arrow-right ms-2"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    // Initialize any custom scripts here
    document.addEventListener('DOMContentLoaded', function() {
        // File upload preview
        const fileInputs = document.querySelectorAll('input[type="file"]');
        fileInputs.forEach(input => {
            input.addEventListener('change', function(e) {
                const previewId = this.id + 'Preview';
                const previewElement = document.getElementById(previewId);
                if (previewElement) {
                    if (this.files.length > 0) {
                        previewElement.classList.remove('d-none');
                    } else {
                        previewElement.classList.add('d-none');
                    }
                }
            });
        });
    });
</script>
<?= $this->endSection() ?>
