
<?php $this->extend('App\Modules\Frontend\Views\Layouts\default') ?>

<?= $this->section('title') ?>Applicant Details - PLC Registration<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
:root {
    --primary: #2563eb;
    --primary-light: #3b82f6;
    --secondary: #f59e0b;
    --dark: #1e293b;
    --gray: #64748b;
    --light: #f8fafc;
    --light-gray: #e9ecef;
    --border-radius: 0.5rem;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.registration-container {
    background: #fff;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow);
    padding: 2rem;
    margin: 2rem auto;
    max-width: 1200px;
}

.registration-header {
    text-align: center;
    margin-bottom: 2.5rem;
}

.registration-header h1 {
    color: var(--dark);
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.registration-header p {
    color: var(--gray);
    font-size: 1.1rem;
}

/* Progress Steps */
.registration-steps {
    display: flex;
    justify-content: space-between;
    margin-bottom: 3rem;
    position: relative;
}

.registration-steps::before {
    content: '';
    position: absolute;
    top: 24px;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--light-gray);
    z-index: 1;
}

.step {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    z-index: 2;
    flex: 1;
}

.step:not(:last-child) {
    padding-right: 10px;
}

.step-number {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: var(--light-gray);
    color: var(--gray);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    margin-bottom: 0.5rem;
    border: 3px solid #fff;
    box-shadow: 0 0 0 2px var(--light-gray);
    transition: all 0.3s ease;
}

.step.active .step-number {
    background: var(--primary);
    color: white;
    box-shadow: 0 0 0 2px var(--primary);
}

.step.completed .step-number {
    background: var(--primary-light);
    color: white;
    box-shadow: 0 0 0 2px var(--primary-light);
}

.step-label {
    font-size: 0.875rem;
    font-weight: 500;
    color: var(--gray);
    text-align: center;
    transition: all 0.3s ease;
}

.step.active .step-label,
.step.completed .step-label {
    color: var(--dark);
    font-weight: 600;
}

/* Form Styles */
.registration-form {
    background: #fff;
    padding: 2rem;
    border-radius: var(--border-radius);
}

.form-section {
    margin-bottom: 2.5rem;
    padding-bottom: 1.5rem;
    border-bottom: 1px solid var(--light-gray);
}

.form-section:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.form-section h3 {
    color: var(--dark);
    font-size: 1.25rem;
    margin-bottom: 1.5rem;
    padding-bottom: 0.75rem;
    border-bottom: 2px solid var(--primary);
    display: inline-block;
}

.form-label {
    font-weight: 500;
    color: var(--dark);
    margin-bottom: 0.5rem;
}

.form-control, .form-select {
    padding: 0.75rem 1rem;
    border: 1px solid #d1d5db;
    border-radius: 0.375rem;
    transition: all 0.2s ease;
    font-size: 0.9375rem;
}

.form-control:focus, .form-select:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

/* File Upload */
.file-upload {
    position: relative;
    margin-bottom: 1rem;
}

.file-upload-input {
    position: absolute;
    left: 0;
    top: 0;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
}

.file-upload-label {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 1.5rem;
    border: 2px dashed #d1d5db;
    border-radius: 0.5rem;
    background: #f9fafb;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s ease;
}

.file-upload-label:hover {
    border-color: var(--primary);
    background: #f0f7ff;
}

.file-upload-icon {
    font-size: 2rem;
    color: var(--primary);
    margin-bottom: 0.5rem;
}

.file-upload-text {
    color: var(--gray);
    font-size: 0.875rem;
}

.file-upload-hint {
    font-size: 0.75rem;
    color: var(--gray);
    margin-top: 0.5rem;
}

/* Buttons */
.btn {
    padding: 0.75rem 1.5rem;
    border-radius: 0.375rem;
    font-weight: 500;
    transition: all 0.2s ease;
}

.btn-primary {
    background-color: var(--primary);
    border-color: var(--primary);
}

.btn-primary:hover {
    background-color: #1d4ed8;
    border-color: #1d4ed8;
}

.btn-outline-secondary {
    color: var(--gray);
    border-color: var(--light-gray);
}

.btn-outline-secondary:hover {
    background-color: #f3f4f6;
    border-color: #d1d5db;
}

/* Responsive */
@media (max-width: 768px) {
    .registration-steps {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .step {
        flex-direction: row;
        margin-bottom: 1rem;
        width: 100%;
    }
    
    .step-number {
        margin-right: 1rem;
        margin-bottom: 0;
    }
    
    .registration-steps::before {
        display: none;
    }
}
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container py-4">
    <div class="registration-container">
        <!-- Registration Header -->
        <div class="registration-header">
            <h1><i class="fas fa-building me-2"></i>Public Limited Company Registration</h1>
            <p class="text-muted">Step 1 of 4: Applicant Personal Details</p>
        </div>
        
        <!-- Progress Steps -->
        <div class="registration-steps">
            <div class="step active">
                <div class="step-number">1</div>
                <div class="step-label">Personal Details</div>
            </div>
            <div class="step">
                <div class="step-number">2</div>
                <div class="step-label">Company Details</div>
            </div>
            <div class="step">
                <div class="step-number">3</div>
                <div class="step-label">Directors & Shareholders</div>
            </div>
            <div class="step">
                <div class="step-number">4</div>
                <div class="step-label">Review & Submit</div>
            </div>
        </div>
        
        <!-- Main Form -->
        <form id="personalDetailsForm" class="registration-form" action="<?= site_url('frontend/plc/process-personal-details') ?>" method="POST">
            <?= csrf_field() ?>
            
            <!-- Personal Information Section -->
            <div class="form-section">
                <h3><i class="fas fa-user-circle me-2"></i>Personal Information</h3>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="firstName" class="form-label">First Name <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="firstName" name="firstName" required 
                                   placeholder="Enter your first name" value="<?= old('firstName') ?>" autofocus>
                        </div>
                    </div>

        <div class="row g-3">
            <!-- First Name -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="first_name" class="form-label">First Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="first_name" name="first_name"
                           value="<?= old('first_name') ?>" required>
                    <?php if (session()->getFlashdata('errors')['first_name'] ?? false): ?>
                        <div class="text-danger small"><?= session()->getFlashdata('errors')['first_name'] ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Surname -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="surname" class="form-label">Surname <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="surname" name="surname"
                           value="<?= old('surname') ?>" required>
                    <?php if (session()->getFlashdata('errors')['surname'] ?? false): ?>
                        <div class="text-danger small"><?= session()->getFlashdata('errors')['surname'] ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Phone -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                    <input type="tel" class="form-control" id="phone" name="phone"
                           value="<?= old('phone') ?>" required>
                    <?php if (session()->getFlashdata('errors')['phone'] ?? false): ?>
                        <div class="text-danger small"><?= session()->getFlashdata('errors')['phone'] ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- WhatsApp (optional) -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="whatsapp" class="form-label">WhatsApp Number</label>
                    <input type="tel" class="form-control" id="whatsapp" name="whatsapp"
                           value="<?= old('whatsapp') ?>">
                </div>
            </div>

            <!-- Email -->
            <div class="col-12">
                <div class="form-group">
                    <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="email" name="email"
                           value="<?= old('email') ?>" required>
                    <?php if (session()->getFlashdata('errors')['email'] ?? false): ?>
                        <div class="text-danger small"><?= session()->getFlashdata('errors')['email'] ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Referral -->
            <div class="col-12">
                <div class="form-group">
                    <label for="referral" class="form-label">How did you hear about us?</label>
                    <input type="text" class="form-control" id="referral" name="referral"
                           value="<?= old('referral') ?>">
                </div>
            </div>
        </div>
    </fieldset>

    <!-- Actions -->
    <div class="d-flex justify-content-between mt-4">
        <button type="reset" class="btn btn-secondary px-4">Clear Form</button>
        <button type="submit" class="btn btn-primary px-4">
            Next
        </button>
    </div>
</form>

                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" required 
                                   placeholder="your.email@example.com" value="<?= old('email') ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-phone"></i></span>
                            <input type="tel" class="form-control" id="phone" name="phone" required 
                                   placeholder="+263 77 123 4567" value="<?= old('phone') ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="idNumber" class="form-label">ID/Passport Number <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                            <input type="text" class="form-control" id="idNumber" name="idNumber" required 
                                   placeholder="e.g., 63-1234567X12" value="<?= old('idNumber') ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="dateOfBirth" class="form-label">Date of Birth <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                            <input type="date" class="form-control" id="dateOfBirth" name="dateOfBirth" required 
                                   value="<?= old('dateOfBirth') ?>">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Residential Address Section -->
            <div class="form-section">
                <h3><i class="fas fa-home me-2"></i>Residential Address</h3>
                <div class="row">
                    <div class="col-12 mb-3">
                        <label for="streetAddress" class="form-label">Street Address <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                            <input type="text" class="form-control" id="streetAddress" name="streetAddress" required 
                                   placeholder="123 Main Street" value="<?= old('streetAddress') ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="city" class="form-label">City <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-city"></i></span>
                            <input type="text" class="form-control" id="city" name="city" required 
                                   placeholder="e.g., Harare" value="<?= old('city') ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="state" class="form-label">State/Province <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-map"></i></span>
                            <input type="text" class="form-control" id="state" name="state" required 
                                   placeholder="e.g., Harare" value="<?= old('state') ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="postalCode" class="form-label">Postal Code <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-mail-bulk"></i></span>
                            <input type="text" class="form-control" id="postalCode" name="postalCode" required 
                                   placeholder="e.g., 00263" value="<?= old('postalCode') ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="country" class="form-label">Country <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-globe-africa"></i></span>
                            <select class="form-select" id="country" name="country" required>
                                <option value="">Select Country</option>
                                <option value="Zimbabwe" <?= old('country') == 'Zimbabwe' ? 'selected' : '' ?>>Zimbabwe</option>
                                <option value="South Africa" <?= old('country') == 'South Africa' ? 'selected' : '' ?>>South Africa</option>
                                <option value="Botswana" <?= old('country') == 'Botswana' ? 'selected' : '' ?>>Botswana</option>
                                <option value="Zambia" <?= old('country') == 'Zambia' ? 'selected' : '' ?>>Zambia</option>
                                <option value="Mozambique" <?= old('country') == 'Mozambique' ? 'selected' : '' ?>>Mozambique</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Document Upload Section -->
            <div class="form-section">
                <h3><i class="fas fa-file-upload me-2"></i>Document Upload</h3>
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <label class="form-label d-block">ID/Passport Copy (Front) <span class="text-danger">*</span></label>
                        <div class="file-upload">
                            <input type="file" id="idFront" name="idFront" class="file-upload-input" accept="image/*,.pdf" required>
                            <label for="idFront" class="file-upload-label">
                                <i class="fas fa-cloud-upload-alt file-upload-icon"></i>
                                <span class="file-upload-text">Click to upload or drag and drop</span>
                                <span class="file-upload-hint">PDF, JPG, or PNG (max 5MB)</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <label class="form-label d-block">ID/Passport Copy (Back) <span class="text-danger">*</span></label>
                        <div class="file-upload">
                            <input type="file" id="idBack" name="idBack" class="file-upload-input" accept="image/*,.pdf" required>
                            <label for="idBack" class="file-upload-label">
                                <i class="fas fa-cloud-upload-alt file-upload-icon"></i>
                                <span class="file-upload-text">Click to upload or drag and drop</span>
                                <span class="file-upload-hint">PDF, JPG, or PNG (max 5MB)</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <label class="form-label d-block">Proof of Residence <span class="text-danger">*</span></label>
                        <div class="file-upload">
                            <input type="file" id="proofOfResidence" name="proofOfResidence" class="file-upload-input" accept="image/*,.pdf" required>
                            <label for="proofOfResidence" class="file-upload-label">
                                <i class="fas fa-file-invoice file-upload-icon"></i>
                                <span class="file-upload-text">Click to upload or drag and drop</span>
                                <span class="file-upload-hint">PDF, JPG, or PNG (max 5MB) - Utility bill or bank statement</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <label class="form-label d-block">Passport Photo <span class="text-danger">*</span></label>
                        <div class="file-upload">
                            <input type="file" id="passportPhoto" name="passportPhoto" class="file-upload-input" accept="image/*" required>
                            <label for="passportPhoto" class="file-upload-label">
                                <i class="fas fa-camera file-upload-icon"></i>
                                <span class="file-upload-text">Click to upload your photo</span>
                                <span class="file-upload-hint">JPG or PNG (max 2MB, 35x45mm, white background)</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form Actions -->
            <div class="d-flex justify-content-between mt-5 pt-3 border-top">
                <a href="<?= site_url('frontend/apply') ?>" class="btn btn-outline-secondary px-4">
                    <i class="fas fa-arrow-left me-2"></i>Back
                </a>
                <button type="submit" class="btn btn-primary px-4">
                    Next: Company Details <i class="fas fa-arrow-right ms-2"></i>
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
