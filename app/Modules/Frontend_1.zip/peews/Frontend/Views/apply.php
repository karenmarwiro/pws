<?php $this->extend('App\Modules\Frontend\Views\Layouts\default') ?>

<?= $this->section('title') ?>Select Registration Type<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    :root {
        --primary: #1b12cd;
        --secondary: #f59e0b;
        --dark: #1e293b;
        --gray: #6c757d;
        --light: #f8f9fa;
        --light-gray: #e9ecef;
        --success: #198754;
        --danger: #dc3545;
        --border-radius: 0.5rem;
    }

    .selection-container {
        background: transparent;
        max-width: 1200px;
        padding: 1.5rem;
        margin: 0 auto;
    }

    .registration-option {
        border: none;
        border-radius: 16px;
        padding: 2rem 1.75rem;
        height: 100%;
        background: white;
        position: relative;
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.1);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        border: 1px solid rgba(0, 0, 0, 0.03);
    }

    .registration-option::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(90deg, var(--primary), #6c5ce7);
        transition: all 0.4s ease;
    }

    .registration-option:hover {
        transform: translateY(-8px) scale(1.01);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.08);
        border-color: rgba(27, 18, 205, 0.1);
    }

    .registration-option:hover::before {
        height: 4px;
        background: linear-gradient(90deg, #ff6b6b, #feca57);
    }

    .registration-option .icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 60px;
        height: 60px;
        border-radius: 16px;
        background: linear-gradient(135deg, rgba(27, 18, 205, 0.1), rgba(108, 92, 231, 0.1));
        font-size: 1.75rem;
        color: var(--primary);
        margin-bottom: 1.25rem;
        transition: all 0.4s ease;
    }

    .registration-option:hover .icon {
        transform: translateY(-3px) scale(1.05);
        background: linear-gradient(135deg, rgba(255, 107, 107, 0.1), rgba(254, 202, 87, 0.1));
        color: #ff6b6b;
    }

    .feature-list {
        margin: 1.25rem 0;
        padding: 0;
    }

    .feature-list li {
        margin-bottom: 0.85rem;
        display: flex;
        align-items: flex-start;
        position: relative;
        padding-left: 1.5rem;
    }

    .feature-list li::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0.4rem;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: var(--primary);
        opacity: 0.5;
        transition: all 0.3s ease;
    }

    .registration-option:hover .feature-list li::before {
        background: #ff6b6b;
        opacity: 1;
        transform: scale(1.2);
    }

    .feature-list i {
        display: none;
    }

    .feature-list strong {
        color: var(--dark);
        font-weight: 600;
        font-size: 0.9rem;
        display: block;
        margin-bottom: 0.15rem;
        transition: all 0.3s ease;
    }

    .registration-option:hover .feature-list strong {
        color: #2d3436;
    }

    .feature-list .small {
        font-size: 0.8rem;
        color: #6c757d;
        line-height: 1.5;
        transition: all 0.3s ease;
    }

    .registration-option:hover .feature-list .small {
        color: #636e72;
    }

    .btn-register {
        padding: 0.7rem 1.5rem;
        font-weight: 600;
        letter-spacing: 0.3px;
        text-transform: none;
        font-size: 0.9rem;
        border-radius: 10px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
        border: none;
        background: linear-gradient(90deg, var(--primary), #6c5ce7);
        color: white;
        box-shadow: 0 4px 15px rgba(27, 18, 205, 0.2);
    }

    .btn-register:hover {
        transform: translateY(-2px);
        box-shadow: 0 7px 20px rgba(27, 18, 205, 0.3);
        color: white;
    }

    .btn-register i {
        transition: transform 0.3s ease;
    }

    .btn-register:hover i {
        transform: translateX(3px);
    }

    .btn-outline-primary {
        background: transparent !important;
        color: var(--primary) !important;
        border: 2px solid var(--primary);
        box-shadow: none;
    }

    .btn-outline-primary:hover {
        background: var(--primary) !important;
        color: white !important;
        border-color: var(--primary);
    }

    .modal-header {
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .modal-footer {
        border-top: 1px solid rgba(0, 0, 0, 0.05);
    }

    @media (max-width: 768px) {
        .selection-container {
            padding: 1.5rem;
            margin: 1rem;
        }
        
        .registration-option {
            margin-bottom: 1.5rem;
        }
    }
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="selection-container">
        <div class="text-center mb-5">
            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 mb-3 rounded-pill">
                <i class="fas fa-rocket me-2"></i> Get Started
            </span>
            <h1 class="display-6 fw-bold text-dark mb-3">
                Choose Your Company Type
            </h1>
            <p class="lead text-muted mb-4" style="max-width: 700px; margin: 0 auto;">
                Select the perfect business structure that aligns with your vision and goals. We'll guide you through the process.
            </p>
            <div class="d-flex justify-content-center align-items-center mt-4">
                <div class="d-flex align-items-center me-4">
                    <div class="me-2">
                        <i class="fas fa-check-circle text-success"></i>
                    </div>
                    <span class="small">Quick Setup</span>
                </div>
                <div class="vr mx-3"></div>
                <div class="d-flex align-items-center me-4">
                    <div class="me-2">
                        <i class="fas fa-check-circle text-success"></i>
                    </div>
                    <span class="small">Expert Support</span>
                </div>
                <div class="vr mx-3 d-none d-md-block"></div>
                <div class="d-flex align-items-center d-none d-md-flex">
                    <div class="me-2">
                        <i class="fas fa-check-circle text-success"></i>
                    </div>
                    <span class="small">Secure Process</span>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- PBC Option -->
            <div class="col-lg-6">
                <div class="registration-option h-100">
                    <div class="d-flex justify-content-between align-items-start mb-4">
                        <div class="icon">
                            <i class="fas fa-briefcase"></i>
                        </div>
                        <span class="badge bg-success bg-opacity-10 text-success px-3 py-2">
                            <i class="fas fa-check-circle me-1"></i> Popular
                        </span>
                    </div>
                    
                    <h3 class="h4 mb-3">Private Business Corporation</h3>
                    <p class="text-muted mb-4">Perfect for small to medium businesses with 1-20 shareholders.</p>
                    
                    <div class="feature-list">
                        <ul class="list-unstyled">
                            <li class="mb-3">
                                <strong>1-20 Shareholders</strong>
                                <p class="small text-muted mb-0">Ideal for small to medium businesses</p>
                            </li>
                            <li class="mb-3">
                                <strong>Limited Liability</strong>
                                <p class="small text-muted mb-0">Protect your personal assets</p>
                            </li>
                            <li class="mb-3">
                                <strong>Tax Advantages</strong>
                                <p class="small text-muted mb-0">Potential tax benefits</p>
                            </li>
                        </ul>
                    </div>
                    
                    <div class="mt-4 pt-2">
                        <a href="<?= site_url('frontend/pbc/personal-details') ?>" class="btn btn-primary btn-register w-100">
                            Get Started <i class="fas fa-arrow-right ms-2"></i>
                        </a>
                        <p class="text-center small mt-3 mb-0 text-muted">
                            <i class="far fa-clock me-1"></i> Takes about 10 minutes
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- PLC Option -->
            <div class="col-lg-6">
                <div class="registration-option h-100">
                    <div class="d-flex justify-content-between align-items-start mb-4">
                        <div class="icon">
                            <i class="fas fa-building"></i>
                        </div>
                        <span class="badge bg-info bg-opacity-10 text-info px-3 py-2">
                            <i class="fas fa-chart-line me-1"></i> Growth
                        </span>
                    </div>
                    
                    <h3 class="h4 mb-3">Public Limited Company</h3>
                    <p class="text-muted mb-4">For businesses planning to offer shares to the public market.</p>
                    
                    <div class="feature-list">
                        <ul class="list-unstyled">
                            <li class="mb-3">
                                <strong>Unlimited Shareholders</strong>
                                <p class="small text-muted mb-0">Raise capital from public</p>
                            </li>
                            <li class="mb-3">
                                <strong>Market Credibility</strong>
                                <p class="small text-muted mb-0">Enhanced business reputation</p>
                            </li>
                            <li class="mb-3">
                                <strong>Capital Access</strong>
                                <p class="small text-muted mb-0">List on stock exchange</p>
                            </li>
                        </ul>
                    </div>
                    
                    <div class="mt-4 pt-2">
                        <a href="<?= site_url('frontend/plc/personal-details') ?>" class="btn btn-outline-primary btn-register w-100">
                            Get Started <i class="fas fa-arrow-right ms-2"></i>
                        </a>
                        <p class="text-center small mt-3 mb-0 text-muted">
                            <i class="far fa-clock me-1"></i> Takes about 15 minutes
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mt-5 pt-5">
            <div class="position-relative">
                <div class="position-absolute top-50 start-50 translate-middle w-100" style="z-index: 1; height: 1px; background: linear-gradient(90deg, transparent, rgba(0,0,0,0.1), transparent);"></div>
                <div class="position-relative" style="z-index: 2; background: white; display: inline-block; padding: 0 2rem;">
                    <button class="btn btn-outline-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#companyTypeHelp">
                        <i class="fas fa-balance-scale me-2"></i> Compare Company Types
                    </button>
                </div>
            </div>
            
            <div class="mt-5 pt-3">
                <div class="row justify-content-center g-4">
                    <div class="col-auto">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <i class="fas fa-headset fa-2x text-primary"></i>
                            </div>
                            <div class="text-start">
                                <h6 class="mb-0 fw-bold">Need Help?</h6>
                                <p class="small text-muted mb-0">Our experts are here to assist you</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <a href="<?= site_url('contact') ?>" class="btn btn-light rounded-pill px-4">
                            <i class="fas fa-comment-dots me-2"></i> Contact Support
                        </a>
                    </div>
                </div>
            </div>
    </div>

    <!-- Help Modal -->
    <div class="modal fade" id="companyTypeHelp" tabindex="-1" aria-labelledby="companyTypeHelpLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="companyTypeHelpLabel">
                        <i class="fas fa-balance-scale me-2"></i> Company Type Comparison
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="px-4 py-3">Feature</th>
                                    <th class="px-4 py-3 text-center">
                                        <span class="badge bg-primary bg-opacity-10 text-primary p-2 w-100">
                                            <i class="fas fa-briefcase me-2"></i> PBC
                                        </span>
                                    </th>
                                    <th class="px-4 py-3 text-center">
                                        <span class="badge bg-primary bg-opacity-10 text-primary p-2 w-100">
                                            <i class="fas fa-building me-2"></i> PLC
                                        </span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="border-top-0">
                                <tr>
                                    <td class="px-4 py-3 fw-medium">Ownership</td>
                                    <td class="px-4 py-3 text-center">
                                        <span class="badge bg-success bg-opacity-10 text-success">1-20 shareholders</span>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <span class="badge bg-success bg-opacity-10 text-success">Unlimited shareholders</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="px-4 py-3 fw-medium">Liability</td>
                                    <td class="px-4 py-3 text-center">
                                        <i class="fas fa-check-circle text-success me-1"></i> Limited
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <i class="fas fa-check-circle text-success me-1"></i> Limited
                                    </td>
                                </tr>
                                <tr>
                                    <td class="px-4 py-3 fw-medium">Capital Raising</td>
                                    <td class="px-4 py-3 text-center">
                                        <span class="text-muted">Private funding only</span>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <span class="text-success fw-medium">Can raise from public</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="px-4 py-3 fw-medium">Regulation</td>
                                    <td class="px-4 py-3 text-center">
                                        <span class="badge bg-light text-muted">Less regulated</span>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <span class="badge bg-light text-muted">Highly regulated</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="px-4 py-3 fw-medium">Best For</td>
                                    <td class="px-4 py-3 text-center">
                                        <small class="d-block text-muted">Small to medium businesses</small>
                                        <small class="d-block text-muted">Family businesses</small>
                                        <small class="d-block text-muted">Startups</small>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <small class="d-block text-muted">Large businesses</small>
                                        <small class="d-block text-muted">Companies planning to go public</small>
                                        <small class="d-block text-muted">High-growth companies</small>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i> Close
                    </button>
                    <a href="<?= site_url('contact') ?>" class="btn btn-primary">
                        <i class="fas fa-headset me-2"></i> Contact Support
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    // Enable Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl, {
            trigger: 'hover',
            placement: 'top',
            html: true
        });
    });

    // Add animation to registration options on scroll
    document.addEventListener('DOMContentLoaded', function() {
        // Animate registration cards
        const animateOnScroll = () => {
            const cards = document.querySelectorAll('.registration-option');
            cards.forEach((card, index) => {
                const cardPosition = card.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;
                
                if (cardPosition < screenPosition) {
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 150 * index);
                }
            });
        };

        // Initialize animation state
        const cards = document.querySelectorAll('.registration-option');
        cards.forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
        });

        // Run animation on load and scroll
        window.addEventListener('load', animateOnScroll);
        window.addEventListener('scroll', animateOnScroll);

        // Initialize popovers
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
        var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl);
        });
    });
</script>

<!-- Add this style for tooltips -->
<style>
    .tooltip {
        font-size: 0.875rem;
    }
    
    .tooltip-inner {
        background-color: var(--dark);
        padding: 0.5rem 1rem;
        border-radius: 0.375rem;
    }
    
    .bs-tooltip-auto[data-popper-placement^=top] .tooltip-arrow::before, 
    .bs-tooltip-top .tooltip-arrow::before {
        border-top-color: var(--dark);
    }
    
    /* Custom animation for modal */
    .modal.fade .modal-dialog {
        transition: transform 0.3s ease-out, opacity 0.3s ease-out;
        transform: translateY(-50px);
        opacity: 0;
    }
    
    .modal.show .modal-dialog {
        transform: translateY(0);
        opacity: 1;
    }
</style>
<?= $this->endSection() ?>