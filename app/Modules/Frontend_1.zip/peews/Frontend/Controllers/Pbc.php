<?php

namespace App\Modules\Frontend\Controllers;

use App\Core\Controllers\FrontendController;

class Pbc extends FrontendController
{
    public function personalDetails()
    {
        $data = [
            'title' => 'Personal Details - PBC Registration',
            'config' => config('App')
        ];
        
        return view('App\Modules\Frontend\Views\pbc\personal_details', $data);
    }
    
    public function processPersonalDetails()
    {
        // Validate the form data
        $validation = \Config\Services::validation();
        
        $validation->setRules([
            'first_name' => 'required|min_length[2]|max_length[50]',
            'surname'    => 'required|min_length[2]|max_length[50]',
            'phone'      => 'required|min_length[10]|max_length[20]',
            'email'      => 'required|valid_email|max_length[100]',
            'whatsapp'   => 'permit_empty|min_length[10]|max_length[20]',
            'referral'   => 'permit_empty|max_length[255]',
        ]);
        
        if (!$validation->withRequest($this->request)->run()) {
            // If validation fails, redirect back with errors
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }
        
        // Get the validated data
        $data = [
            'first_name' => $this->request->getPost('first_name'),
            'surname'    => $this->request->getPost('surname'),
            'phone'      => $this->request->getPost('phone'),
            'whatsapp'   => $this->request->getPost('whatsapp'),
            'email'      => $this->request->getPost('email'),
            'referral'   => $this->request->getPost('referral'),
        ];
        
        // Store data in session
        $session = session();
        $session->set('personal_details', $data);
        
        // Redirect to the next step
        return redirect()->to('pbc/business-details');
    }
    
    public function businessDetails()
    {
    
        
        $data = [
            'title' => 'Company Details - PBC Registration',
            'config' => config('App')
        ];
        
        
         return view('App\Modules\Frontend\Views\pbc\business_details', $data);
    }
    
    public function processCompanyDetails()
    {
        // Check if personal details are in session
        $session = session();
        if (!$session->has('personal_details')) {
            return redirect()->to('pbc/personal-details');
        }
        
        // Validate the form data
        $validation = \Config\Services::validation();
        
        $validation->setRules([
            'name1' => 'required|min_length[2]|max_length[100]',
            'name2' => 'required|min_length[2]|max_length[100]',
            'name3' => 'required|min_length[2]|max_length[100]',
            'name4' => 'required|min_length[2]|max_length[100]',
            'physical_address' => 'required|min_length[5]|max_length[255]',
            'suburb_city' => 'required|min_length[2]|max_length[100]',
            'postal_address' => 'required|min_length[5]|max_length[255]',
            'business_type' => 'required|min_length[2]|max_length[100]',
            'year_end' => 'required|valid_date',
        ]);
        
        if (!$validation->withRequest($this->request)->run()) {
            // If validation fails, redirect back with errors
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }
        
        // Get the validated data
        $companyData = [
            'proposed_names' => [
                $this->request->getPost('name1'),
                $this->request->getPost('name2'),
                $this->request->getPost('name3'),
                $this->request->getPost('name4')
            ],
            'physical_address' => $this->request->getPost('physical_address'),
            'suburb_city' => $this->request->getPost('suburb_city'),
            'postal_address' => $this->request->getPost('postal_address'),
            'business_type' => $this->request->getPost('business_type'),
            'year_end' => $this->request->getPost('year_end'),
        ];
        
        // Store company data in session
        $session->set('company_details', $companyData);
        
        // Redirect to the next step (directors and shareholders)
        return redirect()->to(site_url('frontend/pbc/directors-shareholders'));
    }
    
    public function directorsShareholders()
    {
        
        
        $data = [
            'title' => 'Directors & Shareholders - PBC Registration',
            'config' => config('App')
        ];
        
        
        return view('App\Modules\Frontend\Views\pbc\directors_shareholders', $data);
    }
    
    public function processShareholders()
    {
        // Check if company details are in session
        $session = session();
        if (!$session->has('company_details')) {
            if ($this->request->isAJAX() || $this->request->getHeaderLine('X-Requested-With') === 'XMLHttpRequest') {
                return $this->response->setJSON([
                    'error' => 'Session expired. Please refresh the page and try again.',
                    'redirect' => site_url('pbc/business-details')
                ]);
            }
            return redirect()->to('pbc/business-details');
        }
        
        // Get JSON input
        $json = $this->request->getJSON(true);
        
        // If no JSON data, try to get from POST
        if (empty($json)) {
            $shareholders = $this->request->getPost('shareholders');
        } else {
            $shareholders = $json['shareholders'] ?? null;
        }
        
        // Check if shareholders data is present
        if (empty($shareholders)) {
            return $this->response->setJSON([
                'error' => 'No shareholders data provided.',
                'errors' => ['shareholders' => 'At least one shareholder is required.']
            ])->setStatusCode(400);
        }
        
        // Validate each shareholder
        $errors = [];
        $totalShares = 0;
        
        foreach ($shareholders as $index => $shareholder) {
            // Validate required fields
            if (empty($shareholder['name'])) {
                $errors["shareholders.{$index}.name"] = 'Name is required';
            } elseif (strlen($shareholder['name']) < 2 || strlen($shareholder['name']) > 100) {
                $errors["shareholders.{$index}.name"] = 'Name must be between 2 and 100 characters';
            }
            
            if (empty($shareholder['id'])) {
                $errors["shareholders.{$index}.id"] = 'ID is required';
            } elseif (strlen($shareholder['id']) < 5 || strlen($shareholder['id']) > 50) {
                $errors["shareholders.{$index}.id"] = 'ID must be between 5 and 50 characters';
            }
            
            if (!isset($shareholder['percent'])) {
                $errors["shareholders.{$index}.percent"] = 'Percentage is required';
            } elseif (!is_numeric($shareholder['percent']) || $shareholder['percent'] <= 0 || $shareholder['percent'] > 100) {
                $errors["shareholders.{$index}.percent"] = 'Percentage must be a number between 0.01 and 100';
            } else {
                $totalShares += (float)$shareholder['percent'];
            }
            
            if (empty($shareholder['email'])) {
                $errors["shareholders.{$index}.email"] = 'Email is required';
            } elseif (!filter_var($shareholder['email'], FILTER_VALIDATE_EMAIL)) {
                $errors["shareholders.{$index}.email"] = 'Please enter a valid email address';
            } elseif (strlen($shareholder['email']) > 100) {
                $errors["shareholders.{$index}.email"] = 'Email must not exceed 100 characters';
            }
            
            if (!empty($shareholder['phone']) && strlen($shareholder['phone']) > 20) {
                $errors["shareholders.{$index}.phone"] = 'Phone number must not exceed 20 characters';
            }
        }
        
        // Check total shareholding
        if (abs($totalShares - 100) > 0.01) {
            $errors['shareholders_total'] = 'Total shareholding must equal 100%. Current total: ' . $totalShares . '%';
        }
        
        // If there are validation errors, return them
        if (!empty($errors)) {
            return $this->response->setJSON([
                'error' => 'Validation failed. Please check your inputs.',
                'errors' => $errors
            ])->setStatusCode(422);
        }
        
        // Calculate total shareholding
        $totalShares = array_sum(array_column($shareholders, 'percent'));
        
        // Validate total shareholding equals 100%
        if (abs($totalShares - 100) > 0.01) { // Account for floating point precision
            $error = 'Total shareholding must equal 100%. Current total: ' . $totalShares . '%';
            if ($this->request->isAJAX()) {
                return $this->response->setJSON(['error' => $error]);
            }
            return redirect()->back()->withInput()->with('error', $error);
        }
        
        // Store shareholders data in session
        $session->set('shareholders', $shareholders);
        
        // Prepare response
        $response = [
            'success' => true,
            'message' => 'Shareholder information saved successfully.',
            'redirect' => site_url('pbc/verification')
        ];
        
        if ($this->request->isAJAX()) {
            return $this->response->setJSON($response);
        }
        
        // For non-AJAX requests, redirect to the verification page
        return redirect()->to($response['redirect']);
    }
    
    public function verification()
    {
        $session = session();
        
        // Check if all previous steps are completed
        if (!$session->has('personal_details') || !$session->has('company_details') || !$session->has('shareholders')) {
            return redirect()->to('pbc/personal-details')->with('error', 'Please complete all registration steps first');
        }
        
        $data = [
            'title' => 'Verification - PBC Registration',
            'config' => config('App')
        ];
        
        return view('frontend/layouts/pbc/verification', $data);
    }
    
    public function processVerification()
    {
        $session = session();
        
        // Check if all previous steps are completed
        if (!$session->has('personal_details') || !$session->has('company_details') || !$session->has('shareholders')) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'error' => 'Please complete all registration steps first',
                    'redirect' => site_url('pbc/personal-details')
                ]);
            }
            return redirect()->to('pbc/personal-details')->with('error', 'Please complete all registration steps first');
        }
        
        // Process the verification form
        if ($this->request->getMethod() === 'post') {
            // Here you would typically:
            // 1. Save all the data to the database
            // 2. Send confirmation emails
            // 3. Process payments if applicable
            
            // For now, we'll just generate a reference number
            $applicationId = 'APP' . time();
            
            // Set success message in session
            $session->setFlashdata('success', 'Your application has been submitted successfully!');
            
            $redirectUrl = site_url('pbc/confirmation/' . $applicationId);
            
            // Return JSON response for AJAX requests
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'redirect' => $redirectUrl
                ]);
            }
            
            // Redirect for regular form submission
            return redirect()->to($redirectUrl);
        }
        
        if ($this->request->isAJAX()) {
            return $this->response->setJSON([
                'error' => 'Invalid request method',
                'redirect' => site_url('pbc/verification')
            ]);
        }
        
        return redirect()->back()->with('error', 'Invalid request');
    }
    
    public function reviewSubmit()
    {
        $session = session();
        
        // Check if all previous steps are completed
        if (!$session->has('personal_details') || !$session->has('company_details') || !$session->has('shareholders')) {
            return redirect()->to('pbc/personal-details')->with('error', 'Please complete all registration steps first');
        }
        
        $data = [
            'title' => 'Review & Submit - PBC Registration',
            'config' => config('App'),
            'personal' => $session->get('personal_details'),
            'company' => $session->get('company_details'),
            'shareholders' => $session->get('shareholders')
        ];
        
        return view('frontend/layouts/pbc/review_submit', $data);
    }
    

    
    public function submitApplication()
    {
        // Check if this is an AJAX request
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['error' => 'Invalid request']);
        }
        
        // Load reCAPTCHA secret key from environment
        $recaptchaSecret = getenv('RECAPTCHA_SECRET_KEY');
        $recaptchaResponse = $this->request->getPost('g-recaptcha-response');
        
        // Verify reCAPTCHA
        $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$recaptchaSecret}&response={$recaptchaResponse}");
        $captchaResponse = json_decode($verify);
        
        if (!$captchaResponse->success) {
            return $this->response->setJSON(['error' => 'reCAPTCHA verification failed. Please try again.']);
        }
        
        // Get all session data
        $session = session();
        $personalDetails = $session->get('personal_details');
        $companyDetails = $session->get('company_details');
        $shareholders = $session->get('shareholders');
        
        // At this point, you would typically:
        // 1. Save the application to the database
        // 2. Send confirmation emails
        // 3. Process payment if applicable
        // 4. Any other business logic
        
        try {
            // Example: Save to database (you'll need to implement your model)
            /*
            $applicationModel = new \App\Models\ApplicationModel();
            $applicationId = $applicationModel->insert([
                'personal_details' => json_encode($personalDetails),
                'company_details' => json_encode($companyDetails),
                'shareholders' => json_encode($shareholders),
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s')
            ]);
            */
            
            // For now, we'll just simulate a successful submission
            $applicationId = 'APP' . time();
            
            // Clear session data after successful submission
            $session->remove(['personal_details', 'company_details', 'shareholders']);
            
            // Set success message in session
            $session->setFlashdata('success', 'Your application has been submitted successfully!');
            
            // Return success response with redirect URL
            return $this->response->setJSON([
                'redirect' => site_url('pbc/confirmation/' . $applicationId)
            ]);
            
        } catch (\Exception $e) {
            // Log the error
            log_message('error', 'Application submission failed: ' . $e->getMessage());
            
            // Return error response
            return $this->response->setJSON([
                'error' => 'An error occurred while processing your application. Please try again.'
            ]);
        }
    }
    
    public function confirmation($applicationId = null)
    {
        // Check if we have a success message (in case of direct URL access)
        $session = session();
        if (!$session->has('success') && $applicationId === null) {
            return redirect()->to('pbc/personal-details');
        }
        
        $data = [
            'title' => 'Application Submitted - PBC Registration',
            'config' => config('App'),
            'applicationId' => $applicationId
        ];
        
        return view('frontend/layouts/pbc/confirmation', $data);
    }
}