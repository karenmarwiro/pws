<?php

namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class CompanyDetailsModel extends Model
{
    protected $table            = 'company_details';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'application_id',
        'personal_details_id',
        'proposed_name_one',
        'proposed_name_two',
        'proposed_name_three',
        'proposed_name_four',
        'registration_number',
        'postal_code',
        'suburb_city',
        'country',
        'phone_number',
        'email',
        'website',
        'address',
        'business_type',
        'financial_year_end',
        'created_at',
        'updated_at'
    ];

    // Validation rules
    protected $validationRules = [
        'application_id'      => 'required|is_natural_no_zero',
        'personal_details_id' => 'required|is_natural_no_zero',
        'proposed_name_one'   => 'required|min_length[2]|max_length[255]',
        'proposed_name_two'   => 'required|min_length[2]|max_length[255]',
        'proposed_name_three' => 'permit_empty|min_length[2]|max_length[255]',
        'proposed_name_four'  => 'permit_empty|min_length[2]|max_length[255]',
        'postal_code'         => 'required|max_length[20]',
        'suburb_city'         => 'required|max_length[100]',
        'country'             => 'required|max_length[100]',
        'phone_number'        => 'required|max_length[20]',
        'email'               => 'required|valid_email|max_length[100]',
        'address'             => 'required',
        'business_type'       => 'required|max_length[100]',
        'financial_year_end'  => 'required|valid_date[Y-m-d]'
    ];

    protected $validationMessages = [
        'application_id' => [
            'required' => 'Application ID is required',
            'is_natural_no_zero' => 'Invalid application ID'
        ],
        'personal_details_id' => [
            'required' => 'Personal details ID is required',
            'is_natural_no_zero' => 'Invalid personal details ID'
        ],
        'proposed_name_one' => [
            'required' => 'First proposed company name is required',
            'min_length' => 'Company name must be at least 2 characters long'
        ],
        'proposed_name_two' => [
            'required' => 'Second proposed company name is required',
            'min_length' => 'Company name must be at least 2 characters long'
        ]
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert = ['setCreatedAt'];
    protected $beforeUpdate = ['setUpdatedAt'];

    protected function setCreatedAt(array $data)
    {
        $data['data']['created_at'] = date('Y-m-d H:i:s');
        return $data;
    }

    protected function setUpdatedAt(array $data)
    {
        $data['data']['updated_at'] = date('Y-m-d H:i:s');
        return $data;
    }

    // Find by application ID
    public function findByApplicationId($applicationId)
    {
        return $this->where('application_id', $applicationId)->first();
    }
}
