<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Group routes with admin prefix and auth filter
$routes->group('admin/pbc', ['namespace' => 'App\Modules\PBC\Controllers', 'filter' => 'login'], function($routes) {
    // Main PBC dashboard
    $routes->get('', 'PBC::index', ['as' => 'pbc.index']);
    
    // Application management
    $routes->group('applications', function($routes) {
        // Get applications by status (AJAX)
        $routes->get('get', 'PBC::getApplications', ['as' => 'pbc.applications.get']);
        
        // View application details
        $routes->get('view/(:num)', 'PBC::view/$1', ['as' => 'pbc.applications.view']);
        
        // Update application status (AJAX)
        $routes->post('update-status/(:num)', 'PBC::updateStatus/$1', ['as' => 'pbc.applications.update_status']);
    });
});

// Public routes (if any) can be added here without the auth filter
// $routes->group('pbc', ['namespace' => 'App\Modules\PBC\PBC\Controllers'], function($routes) {
//     // Public routes here
// });
