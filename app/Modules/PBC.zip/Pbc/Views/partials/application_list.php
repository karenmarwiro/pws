<?php if (empty($applications)): ?>
    <div class="text-center py-5">
        <i class="fas fa-inbox fa-4x text-gray-300 mb-3"></i>
        <p class="text-muted">No applications found.</p>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover" id="applicationsTable" width="100%" cellspacing="0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Reference No.</th>
                    <th>Applicant Name</th>
                    <th>Business Name</th>
                    <th>Date Submitted</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $index => $app): ?>
                <tr>
                    <td class="align-middle"><?= $index + 1 ?></td>
                    <td class="align-middle">
                        <strong><?= $app['reference_no'] ?? 'N/A' ?></strong>
                    </td>
                    <td class="align-middle"><?= htmlspecialchars($app['applicant_name'] ?? 'N/A') ?></td>
                    <td class="align-middle"><?= htmlspecialchars($app['business_name'] ?? 'N/A') ?></td>
                    <td class="align-middle">
                        <?= !empty($app['created_at']) ? date('M d, Y', strtotime($app['created_at'])) : 'N/A' ?>
                    </td>
                    <td class="align-middle">
                        <?php 
                        $statusClass = 'secondary';
                        $statusText = 'N/A';
                        
                        if (isset($app['status'])) {
                            $statusText = ucfirst($app['status']);
                            switch (strtolower($app['status'])) {
                                case 'approved':
                                    $statusClass = 'success';
                                    break;
                                case 'pending':
                                case 'processing':
                                    $statusClass = 'warning';
                                    break;
                                case 'rejected':
                                    $statusClass = 'danger';
                                    break;
                                default:
                                    $statusClass = 'info';
                            }
                        }
                        ?>
                        <span class="badge bg-<?= $statusClass ?> text-white">
                            <?= $statusText ?>
                        </span>
                    </td>
                    <td class="align-middle">
                        <div class="btn-group btn-group-sm" role="group">
                            <a href="<?= site_url('admin/pbc/applications/view/' . ($app['id'] ?? '')) ?>" 
                               class="btn btn-outline-primary" 
                               title="View Details"
                               data-bs-toggle="tooltip"
                               data-bs-placement="top">
                                <i class="fas fa-eye"></i>
                            </a>
                            
                            <?php if (in_array(strtolower($app['status'] ?? ''), ['pending', 'processing'])): ?>
                                <button type="button" 
                                        class="btn btn-outline-success btn-update-status" 
                                        data-id="<?= $app['id'] ?? '' ?>" 
                                        data-status="approved"
                                        title="Approve Application"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top">
                                    <i class="fas fa-check"></i>
                                </button>
                                
                                <button type="button" 
                                        class="btn btn-outline-danger btn-update-status" 
                                        data-id="<?= $app['id'] ?? '' ?>" 
                                        data-status="rejected"
                                        title="Reject Application"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top">
                                    <i class="fas fa-times"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if (!empty($applications)): ?>
    <script>
    $(document).ready(function() {
        // Initialize DataTable
        if ($.fn.DataTable.isDataTable('#applicationsTable')) {
            $('#applicationsTable').DataTable().destroy();
        }
        
        const table = $('#applicationsTable').DataTable({
            responsive: true,
            order: [[4, 'desc']], // Sort by date submitted
            pageLength: 10,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search applications...",
            },
            dom: "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
                 "<'row'<'col-sm-12'tr>>" +
                 "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
            columnDefs: [
                { orderable: false, targets: [0, 6] }, // Disable sorting on # and Actions columns
                { className: 'text-center', targets: [0, 5, 6] } // Center align these columns
            ]
        });
        
        // Initialize tooltips
        $('[data-bs-toggle="tooltip"]').tooltip();
    });
    </script>
    <?php endif; ?>
<?php endif; ?>
