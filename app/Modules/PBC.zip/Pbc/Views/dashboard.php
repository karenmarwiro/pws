<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBC Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .nav-tabs .nav-link {
            font-weight: 500;
            color: #6c757d;
            border: none;
            padding: 12px 20px;
            margin-right: 5px;
        }
        .nav-tabs .nav-link.active {
            color: #0d6efd;
            background-color: #fff;
            border-bottom: 3px solid #0d6efd;
        }
        .nav-tabs {
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 20px;
        }
        .tab-content {
            padding: 20px;
            background: #fff;
            border-radius: 0 0 5px 5px;
        }
        .card {
            border: none;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #eee;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container-fluid py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-tasks me-2"></i>PBC Dashboard</h2>
                <p class="text-muted">Manage PBC applications and their status</p>
            </div>
        </div>

        <!-- Tab Navigation -->
        <ul class="nav nav-tabs" id="pbcTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="applications-tab" data-bs-toggle="tab" 
                        data-bs-target="#applications" type="button" role="tab">
                    <i class="fas fa-list me-1"></i> All Applications
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pending-tab" data-bs-toggle="tab" 
                        data-bs-target="#pending" type="button" role="tab">
                    <i class="fas fa-clock me-1"></i> Pending/Processing
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="approved-tab" data-bs-toggle="tab" 
                        data-bs-target="#approved" type="button" role="tab">
                    <i class="fas fa-check-circle me-1"></i> Approved
                </button>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content" id="pbcTabsContent">
            <!-- All Applications Tab -->
            <div class="tab-pane fade show active" id="applications" role="tabpanel" aria-labelledby="applications-tab">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>All Applications</span>
                        <span class="badge bg-primary rounded-pill">24</span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Reference No.</th>
                                        <th>Applicant</th>
                                        <th>Business</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>PBC-2023-001</td>
                                        <td>John Doe</td>
                                        <td>ABC Corp</td>
                                        <td>2023-10-15</td>
                                        <td><span class="badge bg-warning">Pending</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary">View</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>PBC-2023-002</td>
                                        <td>Jane Smith</td>
                                        <td>XYZ Ltd</td>
                                        <td>2023-10-14</td>
                                        <td><span class="badge bg-info">Processing</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary">View</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>PBC-2023-003</td>
                                        <td>Robert Johnson</td>
                                        <td>123 Industries</td>
                                        <td>2023-10-13</td>
                                        <td><span class="badge bg-success">Approved</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary">View</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pending/Processing Tab -->
            <div class="tab-pane fade" id="pending" role="tabpanel" aria-labelledby="pending-tab">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Pending/Processing Applications</span>
                        <span class="badge bg-warning rounded-pill">15</span>
                    </div>
                    <div class="card-body">
                        <p>Applications that are currently being reviewed or awaiting action.</p>
                        <!-- Sample content -->
                        <div class="list-group">
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">PBC-2023-001 - John Doe</h6>
                                    <small>3 days ago</small>
                                </div>
                                <p class="mb-1">ABC Corp - Awaiting document verification</p>
                                <small class="text-muted">Status: <span class="text-warning">Pending</span></small>
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">PBC-2023-004 - Alice Brown</h6>
                                    <small>1 day ago</small>
                                </div>
                                <p class="mb-1">Brown Enterprises - Under review</p>
                                <small class="text-muted">Status: <span class="text-info">Processing</span></small>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Approved Tab -->
            <div class="tab-pane fade" id="approved" role="tabpanel" aria-labelledby="approved-tab">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Approved Applications</span>
                        <span class="badge bg-success rounded-pill">9</span>
                    </div>
                    <div class="card-body">
                        <p>Applications that have been approved.</p>
                        <!-- Sample content -->
                        <div class="list-group">
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">PBC-2023-003 - Robert Johnson</h6>
                                    <small>2 weeks ago</small>
                                </div>
                                <p class="mb-1">123 Industries - Full approval granted</p>
                                <small class="text-muted">Approved on: 2023-10-05</small>
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">PBC-2023-005 - Sarah Wilson</h6>
                                    <small>1 month ago</small>
                                </div>
                                <p class="mb-1">Wilson & Co - Conditional approval</p>
                                <small class="text-muted">Approved on: 2023-09-15</small>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
