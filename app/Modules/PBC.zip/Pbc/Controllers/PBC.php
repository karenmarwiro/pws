<?php

namespace App\Modules\PBC\Controllers;

use App\Core\Controllers\AdminController;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class PBC extends AdminController
{
    protected $module = 'PBC';
    protected $viewPath = 'App\Modules\PBC\Views';
    protected $db;
    
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        
        // Load necessary helpers and libraries
        helper(['form', 'url']);
        $this->db = \Config\Database::connect();
        
        // Set the theme if needed
        if (isset($this->template) && method_exists($this->template, 'set_theme')) {
            $this->template->set_theme('admin');
        }
    }
    
    public function index()
    {
        $data = [
            'title' => 'PBC Applications',
            'tab' => $this->request->getGet('tab') ?? 'applications',
            'coreViewPath' => APPPATH . 'Views/'
        ];
        
        return view('App\Modules\PBC\Views\index', $data);
    }
    
    public function getApplications()
    {
        $status = $this->request->getGet('status') ?? 'all';
        
        // Get applications based on status
        $builder = $this->db->table('pbc_applications');
        
        if ($status !== 'all') {
            $builder->where('status', $status);
        }
        
        $applications = $builder->orderBy('created_at', 'DESC')
                              ->get()
                              ->getResultArray();
        
        $data = [
            'applications' => $applications,
            'status' => $status
        ];
        
        return view('App\Modules\PBC\Views\partials\application_list', $data);
    }
    
    public function view($id = null)
    {
        // Get application details
        $application = $this->db->table('pbc_applications')
                               ->where('id', $id)
                               ->get()
                               ->getRowArray();
        
        if (empty($application)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Application not found.'
            ]);
        }
        
        $data['application'] = $application;
        $data['title'] = 'View Application';
        return view('App\Modules\PBC\Views\view_application', $data);
    }
    
    public function updateStatus($id = null)
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Invalid request method.'
            ]);
        }
        
        $status = $this->request->getPost('status');
        
        if (!in_array($status, ['approved', 'rejected', 'processing'])) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Invalid status.'
            ]);
        }
        
        // Update application status
        $this->db->table('pbc_applications')
                ->where('id', $id)
                ->update([
                    'status' => $status,
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
        
        return $this->response->setJSON([
            'success' => true,
            'message' => 'Application status updated successfully.'
        ]);
    }

   public function migrate()
{
    $migrate = \Config\Services::migrations();
    $migrate->setNamespace('App\Modules\PBC');

    try {
        $migrate->latest();
        return $this->response->setJSON([
            'success' => true,
            'message' => 'Migrations applied successfully!'
        ]);
    } catch (\Throwable $e) {
        log_message('error', 'Migration failed: ' . $e->getMessage());
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Migration failed: ' . $e->getMessage()
        ]);
    }
}

}


