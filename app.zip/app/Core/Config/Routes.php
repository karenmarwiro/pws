<?php

namespace app\Core\Config;

use CodeIgniter\Config\BaseConfig;
use Config\Services;

$routes = Services::routes();

$routes->get('/', 'App\Core\Controllers\AdminController::dashboard');
$routes->get('/dashboard', '\App\Core\Controllers\AdminController::dashboard');
$routes->get('settings', 'Settings::index', ['namespace' => 'App\Core\Controllers']);
$routes->post('settings/save', 'Settings::save', ['namespace' => 'App\Core\Controllers']);
$routes->get('modules', 'Modules::index', ['namespace' => 'App\Core\Controllers']);
$routes->get('modules/add', 'Modules::add', ['namespace' => 'App\Core\Controllers']);
$routes->get('modules/edit/(:num)', 'Modules::edit/$1', ['namespace' => 'App\Core\Controllers']);
$routes->get('modules/delete/(:num)', 'Modules::delete/$1', ['namespace' => 'App\Core\Controllers']);
$routes->post('modules/upload', 'Modules::upload', ['namespace' => 'App\Core\Controllers']);

// API Routes
$routes->group('api', ['namespace' => 'App\Core\Controllers'], function($routes) {
    $routes->post('modules/(:num)/toggle', 'Modules::toggle/$1', ['namespace' => 'App\Core\Controllers']);
});

$routes->group('team', ['namespace' => 'App\Core\Controllers'], function($routes){
    $routes->get('', 'Team::index');
    $routes->get('add', 'Team::add');
    $routes->get('edit/(:num)', 'Team::edit/$1');
});

$routes->group('clients', ['namespace' => 'App\Core\Controllers'], function($routes){
    $routes->get('', 'Clients::index');
    $routes->get('add', 'Clients::add');
    $routes->get('edit/(:num)', 'Clients::edit/$1');
    $routes->get('view/(:num)', 'Clients::view/$1');   
    $routes->get('delete/(:num)', 'Clients::delete/$1');
});

$routes->group('projects', ['namespace' => 'App\Core\Controllers'], function($routes){
    $routes->get('', 'Projects::index');
    $routes->get('add', 'Projects::add');
    $routes->get('edit/(:num)', 'Projects::edit/$1');
});

$routes->group('tasks', ['namespace' => 'App\Core\Controllers'], function($routes){
    $routes->get('', 'Tasks::index');
    $routes->get('add', 'Tasks::add');
    $routes->get('edit/(:num)', 'Tasks::edit/$1');
});

$routes->group('rbac', ['filter' => 'auth', 'namespace' => 'App\Core\Controllers'], function($routes) {
    $routes->get('/', 'RBAC::index');
    $routes->get('manage-roles', 'RBAC::manageUserRoles');
    $routes->post('manage-roles', 'RBAC::manageUserRoles');
    $routes->get('manage-roles/(:num)', 'RBAC::manageUserRoles/$1');
    $routes->get('manage-permissions/(:any)', 'RBAC::manageRolePermissions/$1');
    $routes->post('manage-permissions/(:any)', 'RBAC::manageRolePermissions/$1');
    $routes->get('users-by-role/(:any)', 'RBAC::usersByRole/$1');
    $routes->get('assign-role/(:num)/(:any)', 'RBAC::assignRole/$1/$2');
    $routes->get('remove-role/(:num)/(:any)', 'RBAC::removeRole/$1/$2');
});