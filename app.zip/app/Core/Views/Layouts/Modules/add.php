
<!-- Header -->
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="h4 mb-1 fw-bold">
                        <i class="fas fa-plus-circle me-2 text-primary"></i>Add New Module
                    </h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?= site_url('dashboard') ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?= site_url('modules') ?>">Modules</a></li>
                            <li class="breadcrumb-item active">Add Module</li>
                        </ol>
                    </nav>
                </div>
                <div>
                    <a href="<?= site_url('modules') ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Modules
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="mb-0 fw-bold">
                        <i class="fas fa-upload me-2 text-primary"></i>Upload Module Package
                    </h5>
                </div>
                <div class="card-body p-4">
                    <div class="alert alert-info border-0">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-info-circle fa-lg mt-1"></i>
                            </div>
                            <div class="ms-3">
                                <h6 class="alert-heading mb-1">Module Package Requirements</h6>
                                <ul class="mb-0 ps-3">
                                    <li>Only <span class="fw-bold">.zip</span> files are accepted</li>
                                    <li>Maximum file size: <span class="fw-bold">50MB</span></li>
                                    <li>Must contain a valid <code>module.json</code> file</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <form id="moduleUploadForm" action="<?= site_url('modules/upload') ?>" method="post" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        <div class="dropzone" id="moduleDropzone">
                            <div class="dropzone-inner">
                                <i class="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
                                <h5 class="mb-2">Drag & drop your module package here</h5>
                                <p class="text-muted mb-3">or</p>
                                <button type="button" class="btn btn-primary" id="browseBtn">
                                    <i class="fas fa-folder-open me-2"></i>Browse File
                                </button>
                                <input type="file" name="module_zip" id="fileInput" class="d-none" accept=".zip">
                                <p class="small text-muted mt-3 mb-0">Supported format: .zip (max 50MB)</p>
                            </div>
                        </div>

                        <!-- File Preview -->
                        <div id="filePreview" class="mt-4 d-none">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body p-3">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <i class="fas fa-file-archive fa-2x text-primary"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1" id="fileName"></h6>
                                            <p class="text-muted small mb-0" id="fileSize"></p>
                                        </div>
                                        <button type="button" class="btn-close" id="removeFileBtn" aria-label="Remove file"></button>
                                    </div>
                                    <div class="progress mt-2 d-none" id="uploadProgressContainer">
                                        <div id="uploadProgress" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <a href="<?= site_url('modules') ?>" class="btn btn-outline-secondary me-md-2">
                                <i class="fas fa-times me-1"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary" id="uploadBtn" disabled>
                                <i class="fas fa-upload me-1"></i> Upload Module
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Dropzone Styles */
.dropzone {
    min-height: 240px;
    border: 2px dashed #dee2e6;
    border-radius: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    background-color: #f8f9fa;
    position: relative;
    overflow: hidden;
}

.dropzone:hover, .dropzone.dragover {
    border-color: #0d6efd;
    background-color: rgba(13, 110, 253, 0.05);
}

.dropzone.dragover::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(13, 110, 253, 0.1);
    z-index: 1;
}

.dz-message {
    padding: 2rem 1rem;
    position: relative;
    z-index: 2;
}

/* File Preview Styles */
.file-preview {
    background: #fff;
    border: 1px solid #e9ecef;
    border-radius: 0.5rem;
    padding: 1rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    transition: all 0.2s;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.05);
}

.file-preview:hover {
    transform: translateY(-2px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.05);
}

.file-icon {
    font-size: 1.75rem;
    margin-right: 1rem;
    color: #6c757d;
    min-width: 2.5rem;
    text-align: center;
}

.file-info {
    flex: 1;
    min-width: 0;
    overflow: hidden;
}

.file-name {
    font-weight: 500;
    margin-bottom: 0.25rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.file-size {
    font-size: 0.8125rem;
    color: #6c757d;
}

.file-actions {
    display: flex;
    align-items: center;
    margin-left: 1rem;
}

.file-remove {
    color: #dc3545;
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 0.25rem;
    transition: background-color 0.2s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 2rem;
    height: 2rem;
}

.file-remove:hover {
    background-color: rgba(220, 53, 69, 0.1);
}

/* Progress Bar */
.progress {
    height: 0.5rem;
    margin-top: 0.5rem;
    border-radius: 0.25rem;
    overflow: hidden;
    background-color: #e9ecef;
}

.progress-bar {
    background-color: #0d6efd;
    transition: width 0.6s ease;
}

/* Alert Styling */
.alert {
    border: none;
    border-radius: 0.5rem;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.05);
}

.alert-info {
    background-color: #f0f7ff;
    color: #084298;
}

/* Button Styles */
.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: 500;
    transition: all 0.2s;
}

.btn i {
    font-size: 0.875em;
}

/* Responsive Adjustments */
@media (max-width: 767.98px) {
    .dropzone {
        padding: 1.5rem;
    }
    
    .file-preview {
        flex-direction: column;
        text-align: center;
    }
    
    .file-icon {
        margin-right: 0;
        margin-bottom: 0.5rem;
    }
    
    .file-actions {
        margin-left: 0;
        margin-top: 0.75rem;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize elements
    const dropzone = document.getElementById('moduleDropzone');
    const fileInput = document.getElementById('fileInput');
    const browseBtn = document.getElementById('browseBtn');
    const uploadForm = document.getElementById('moduleUploadForm');
    const filePreview = document.getElementById('filePreview');
    const fileName = document.getElementById('fileName');
    const fileSize = document.getElementById('fileSize');
    const removeFileBtn = document.getElementById('removeFileBtn');
    const uploadBtn = document.getElementById('uploadBtn');
    const uploadProgress = document.getElementById('uploadProgress');
    const uploadProgressContainer = document.getElementById('uploadProgressContainer');

    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropzone.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    // Highlight dropzone when item is dragged over it
    ['dragenter', 'dragover'].forEach(eventName => {
        dropzone.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropzone.addEventListener(eventName, unhighlight, false);
    });

    // Handle dropped files
    dropzone.addEventListener('drop', handleDrop, false);

    // Handle file selection via browse button
    browseBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileSelect, false);

    // Handle remove file button
    removeFileBtn.addEventListener('click', resetFileInput);

    // Form submission
    uploadForm.addEventListener('submit', handleFormSubmit);

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function highlight() {
        dropzone.classList.add('highlight');
    }

    function unhighlight() {
        dropzone.classList.remove('highlight');
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    function handleFileSelect(e) {
        const files = e.target.files;
        handleFiles(files);
    }

    function handleFiles(files) {
        if (files.length === 0) return;
        
        const file = files[0];
        
        // Validate file type
        const isValidType = file.type === 'application/zip' || file.name.endsWith('.zip');
        
        // Validate file size (50MB max)
        const isValidSize = file.size <= 50 * 1024 * 1024; // 50MB
        
        if (!isValidType) {
            showError('Invalid File Type', 'Only .zip files are allowed.');
            return;
        }
        
        if (!isValidSize) {
            showError('File Too Large', 'Maximum file size is 50MB.');
            return;
        }
        
        // Display file preview
        fileName.textContent = file.name;
        fileSize.textContent = formatFileSize(file.size);
        filePreview.classList.remove('d-none');
        uploadBtn.disabled = false;
    }

    function resetFileInput() {
        fileInput.value = '';
        filePreview.classList.add('d-none');
        uploadBtn.disabled = true;
        uploadProgressContainer.classList.add('d-none');
        uploadProgress.style.width = '0%';
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    async function handleFormSubmit(e) {
        e.preventDefault();
        
        if (!fileInput.files || fileInput.files.length === 0) {
            showError('Error', 'Please select a module file to upload.');
            return;
        }
        
        const formData = new FormData(uploadForm);
        
        try {
            // Disable form and show loading state
            uploadBtn.disabled = true;
            uploadBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Uploading...';
            uploadProgressContainer.classList.remove('d-none');
            
            // Show upload progress
            const xhr = new XMLHttpRequest();
            
            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    uploadProgress.style.width = percentComplete + '%';
                }
            }, false);
            
            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 300) {
                    const response = JSON.parse(xhr.responseText);
                    
                    if (response.success) {
                        showSuccess('Success', response.message);
                        
                        // Redirect to modules page after a short delay
                        setTimeout(() => {
                            window.location.href = response.redirect || '<?= site_url('modules') ?>';
                        }, 1500);
                    } else {
                        showError('Upload Failed', response.message || 'An error occurred while uploading the module.');
                        uploadBtn.disabled = false;
                        uploadBtn.innerHTML = '<i class="fas fa-upload me-1"></i> Upload Module';
                        uploadProgressContainer.classList.add('d-none');
                    }
                } else {
                    let errorMessage = 'An error occurred while uploading the module.';
                    try {
                        const errorResponse = JSON.parse(xhr.responseText);
                        errorMessage = errorResponse.message || errorMessage;
                    } catch (e) {
                        console.error('Error parsing error response:', e);
                    }
                    
                    showError('Upload Failed', errorMessage);
                    uploadBtn.disabled = false;
                    uploadBtn.innerHTML = '<i class="fas fa-upload me-1"></i> Upload Module';
                    uploadProgressContainer.classList.add('d-none');
                }
            };
            
            xhr.onerror = function() {
                showError('Upload Failed', 'A network error occurred. Please check your connection and try again.');
                uploadBtn.disabled = false;
                uploadBtn.innerHTML = '<i class="fas fa-upload me-1"></i> Upload Module';
                uploadProgressContainer.classList.add('d-none');
            };
            
            xhr.open('POST', uploadForm.action, true);
            xhr.send(formData);
            
        } catch (error) {
            console.error('Upload error:', error);
            showError('Upload Failed', 'An unexpected error occurred. Please try again.');
            uploadBtn.disabled = false;
            uploadBtn.innerHTML = '<i class="fas fa-upload me-1"></i> Upload Module';
            uploadProgressContainer.classList.add('d-none');
        }
    }

    function showError(title, message) {
        // Remove any existing alerts
        const existingAlert = document.querySelector('.alert.alert-danger');
        if (existingAlert) {
            existingAlert.remove();
        }
        
        const alert = document.createElement('div');
        alert.className = 'alert alert-danger alert-dismissible fade show';
        alert.role = 'alert';
        alert.innerHTML = `
            <div class="d-flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-exclamation-circle fa-lg mt-1"></i>
                </div>
                <div class="ms-3">
                    <h6 class="alert-heading mb-1">${title}</h6>
                    <div class="mb-0">${message}</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        document.querySelector('.card-body').insertBefore(alert, uploadForm);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    }

    function showSuccess(title, message) {
        // Remove any existing alerts
        const existingAlert = document.querySelector('.alert.alert-success');
        if (existingAlert) {
            existingAlert.remove();
        }
        
        const alert = document.createElement('div');
        alert.className = 'alert alert-success alert-dismissible fade show';
        alert.role = 'alert';
        alert.innerHTML = `
            <div class="d-flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-check-circle fa-lg mt-1"></i>
                </div>
                <div class="ms-3">
                    <h6 class="alert-heading mb-1">${title}</h6>
                    <div class="mb-0">${message}</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        document.querySelector('.card-body').insertBefore(alert, uploadForm);
    }
});
</script>