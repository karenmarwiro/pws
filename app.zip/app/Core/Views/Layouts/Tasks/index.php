<!-- Header -->
<?php include $coreViewPath . 'Partials/header.php'; ?>

<!-- Sidebar/Menu -->
<?php include $coreViewPath . 'Partials/menu.php'; ?>

tasks here 
<!-- Footer -->
<?php include $coreViewPath . 'Partials/footer.php'; ?>

