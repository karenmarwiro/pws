<!-- Header -->
<?php include $coreViewPath . 'Partials/header.php'; ?>

<!-- Sidebar/Menu -->
<?php include $coreViewPath . 'Partials/menu.php'; ?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="h3 mb-0"><?= esc($title) ?></h1>
                <button type="submit" form="settings-form" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Changes
                </button>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <form id="settings-form" action="<?= site_url('settings/save') ?>" method="post">
                <?= csrf_field() ?>
                
                <div class="card card-primary card-outline card-outline-tabs">
                    <div class="card-header p-0 border-bottom-0">
                        <ul class="nav nav-tabs" id="settings-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="general-tab" data-bs-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">
                                    <i class="fas fa-cog me-1"></i> General
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="appearance-tab" data-bs-toggle="tab" href="#appearance" role="tab" aria-controls="appearance" aria-selected="false">
                                    <i class="fas fa-paint-brush me-1"></i> Appearance
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="notifications-tab" data-bs-toggle="tab" href="#notifications" role="tab" aria-controls="notifications" aria-selected="false">
                                    <i class="fas fa-bell me-1"></i> Notifications
                                </a>
                            </li>
                        </ul>
                    </div>
                    
                    <div class="card-body">
                        <div class="tab-content" id="settings-tab-content">
                            <!-- General Settings Tab -->
                            <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="site_name" class="form-label">Site Name</label>
                                            <input type="text" class="form-control" id="site_name" name="site_name" value="PWS Prototype">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="site_url" class="form-label">Site URL</label>
                                            <input type="url" class="form-control" id="site_url" name="site_url" value="https://example.com">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="admin_email" class="form-label">Admin Email</label>
                                            <input type="email" class="form-control" id="admin_email" name="admin_email" value="admin@example.com">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="timezone" class="form-label">Timezone</label>
                                            <select class="form-select" id="timezone" name="timezone">
                                                <option value="UTC" selected>UTC</option>
                                                <option value="America/New_York">Eastern Time (ET)</option>
                                                <option value="America/Chicago">Central Time (CT)</option>
                                                <option value="America/Denver">Mountain Time (MT)</option>
                                                <option value="America/Los_Angeles">Pacific Time (PT)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="language" class="form-label">Language</label>
                                    <select class="form-select" id="language" name="language">
                                        <option value="en_US" selected>English (US)</option>
                                        <option value="es_ES">Español</option>
                                        <option value="fr_FR">Français</option>
                                        <option value="de_DE">Deutsch</option>
                                    </select>
                                </div>
                            </div>
                            
                            <!-- Appearance Tab -->
                            <div class="tab-pane fade" id="appearance" role="tabpanel" aria-labelledby="appearance-tab">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="theme" class="form-label">Theme</label>
                                            <select class="form-select" id="theme" name="theme">
                                                <option value="default" selected>Default</option>
                                                <option value="dark">Dark Mode</option>
                                                <option value="light">Light Mode</option>
                                                <option value="blue">Blue Theme</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="sidebar_style" class="form-label">Sidebar Style</label>
                                            <select class="form-select" id="sidebar_style" name="sidebar_style">
                                                <option value="expanded" selected>Expanded</option>
                                                <option value="collapsed">Collapsed</option>
                                                <option value="mini">Mini</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">Color Scheme</label>
                                    <div class="d-flex gap-2">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="color_scheme" id="color_light" value="light" checked>
                                            <label class="form-check-label" for="color_light">Light</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="color_scheme" id="color_dark" value="dark">
                                            <label class="form-check-label" for="color_dark">Dark</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="color_scheme" id="color_auto" value="auto">
                                            <label class="form-check-label" for="color_auto">Auto (System Preference)</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="logo" class="form-label">Logo</label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
                                        <button class="btn btn-outline-secondary" type="button" id="upload-logo">
                                            <i class="fas fa-upload me-1"></i> Upload
                                        </button>
                                    </div>
                                    <small class="form-text text-muted">Recommended size: 180x50px</small>
                                </div>
                            </div>
                            
                            <!-- Notifications Tab -->
                            <div class="tab-pane fade" id="notifications" role="tabpanel" aria-labelledby="notifications-tab">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" <?= ($settings['email_notifications'] ?? true) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="email_notifications">Enable Email Notifications</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="browser_notifications" name="browser_notifications" <?= ($settings['browser_notifications'] ?? false) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="browser_notifications">Enable Browser Notifications</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="desktop_notifications" name="desktop_notifications" <?= ($settings['desktop_notifications'] ?? false) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="desktop_notifications">Enable Desktop Notifications</label>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="notification_sound" class="form-label">Notification Sound</label>
                                    <select class="form-select" id="notification_sound" name="notification_sound">
                                        <option value="default" selected>Default</option>
                                        <option value="chime">Chime</option>
                                        <option value="ding">Ding</option>
                                        <option value="bell">Bell</option>
                                        <option value="none">None</option>
                                    </select>
                                </div>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>
                                    Notification settings will apply to all users. Users can override these in their profile settings.
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-footer text-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </section>
</div>

<!-- Footer -->
<?php include $coreViewPath . 'Partials/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Apply saved theme and color scheme
    function applyTheme() {
        const theme = '<?= $settings['theme'] ?? 'default' ?>';
        const colorScheme = '<?= $settings['color_scheme'] ?? 'light' ?>';
        
        // Remove existing theme classes
        document.documentElement.classList.remove('theme-default', 'theme-dark', 'theme-light', 'theme-blue');
        document.documentElement.classList.add(`theme-${theme}`);
        
        // Apply color scheme
        if (colorScheme === 'dark' || (colorScheme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.setAttribute('data-bs-theme', 'dark');
        } else {
            document.documentElement.setAttribute('data-bs-theme', 'light');
        }
    }
    
    // Apply theme on load
    applyTheme();
    
    // Listen for system color scheme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);
    
    // Initialize Bootstrap tabs
    var tabElms = [].slice.call(document.querySelectorAll('button[data-bs-toggle="tab"]'));
    tabElms.forEach(function(tabEl) {
        tabEl.addEventListener('click', function (e) {
            e.preventDefault();
            var tab = new bootstrap.Tab(tabEl);
            tab.show();
        });
    });

    // Handle logo upload preview
    const logoInput = document.getElementById('logo');
    if (logoInput) {
        logoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // You can add image preview logic here if needed
                console.log('Selected file:', file.name);
            }
        });
    }

    // Form submission handling
    const form = document.getElementById('settings-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Add loading state
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Saving...';
            
            // Create FormData object
            const formData = new FormData(form);
            
            // Convert form data to JSON
            const formObject = {};
            const checkboxes = ['email_notifications', 'browser_notifications', 'desktop_notifications'];
            
            formData.forEach((value, key) => {
                // Handle checkboxes - check if the key is in our checkboxes array
                if (checkboxes.includes(key)) {
                    formObject[key] = formData.get(key) === 'on' ? true : false;
                } else {
                    formObject[key] = value;
                }
            });
            
            // Send AJAX request
            fetch(form.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify(formObject)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message
                    const toast = document.createElement('div');
                    toast.className = 'position-fixed bottom-0 end-0 m-3 alert alert-success alert-dismissible fade show';
                    toast.role = 'alert';
                    toast.innerHTML = `
                        <i class="fas fa-check-circle me-2"></i>
                        ${data.message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    `;
                    document.body.appendChild(toast);
                    
                    // Apply theme changes immediately
                    applyTheme();
                    
                    // Remove toast after 3 seconds
                    setTimeout(() => {
                        toast.remove();
                    }, 3000);
                } else {
                    throw new Error(data.message || 'Failed to save settings');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error saving settings: ' + error.message);
            })
            .finally(() => {
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            });
        });
    }
});
</script>
