<!-- Header -->
<?php include $coreViewPath . 'Partials/header.php'; ?>

<!-- Sidebar/Menu -->
<?php include $coreViewPath . 'Partials/menu.php'; ?>

<div class="container-fluid px-4">
    <h1 class="mt-4"><?= esc($title) ?></h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Welcome back, <?= auth()->user()->username ?? 'Admin' ?>!</li>
    </ol>

    <!-- Stat Cards -->
    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4 shadow-sm">
                <div class="card-body">
                    <i class="bi bi-people me-2"></i> Users
                    <h3 class="mt-2">1,240</h3>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?= base_url('users') ?>">View Details</a>
                    <i class="bi bi-arrow-right-circle"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4 shadow-sm">
                <div class="card-body">
                    <i class="bi bi-box-seam me-2"></i> Products
                    <h3 class="mt-2">320</h3>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?= base_url('products') ?>">View Details</a>
                    <i class="bi bi-arrow-right-circle"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4 shadow-sm">
                <div class="card-body">
                    <i class="bi bi-journal-text me-2"></i> Posts
                    <h3 class="mt-2">54</h3>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?= base_url('posts') ?>">View Details</a>
                    <i class="bi bi-arrow-right-circle"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-danger text-white mb-4 shadow-sm">
                <div class="card-body">
                    <i class="bi bi-chat-dots me-2"></i> Comments
                    <h3 class="mt-2">876</h3>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?= base_url('comments') ?>">View Details</a>
                    <i class="bi bi-arrow-right-circle"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row">
        <div class="col-xl-6">
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <i class="bi bi-bar-chart-line"></i> User Growth (Dummy Data)
                </div>
                <div class="card-body">
                    <canvas id="userChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <i class="bi bi-pie-chart"></i> Products Distribution (Dummy Data)
                </div>
                <div class="card-body">
                    <canvas id="productChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<?php include $coreViewPath . 'Partials/footer.php'; ?>

<!-- Charts Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Dummy User Growth Chart
    new Chart(document.getElementById("userChart"), {
        type: "line",
        data: {
            labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
            datasets: [{
                label: "Users",
                data: [120, 150, 180, 220, 260, 300],
                borderColor: "rgba(13, 110, 253, 0.8)",
                backgroundColor: "rgba(13, 110, 253, 0.2)",
                fill: true,
                tension: 0.3
            }]
        }
    });

    // Dummy Product Distribution
    new Chart(document.getElementById("productChart"), {
        type: "doughnut",
        data: {
            labels: ["Electronics", "Clothing", "Books", "Others"],
            datasets: [{
                data: [120, 90, 60, 50],
                backgroundColor: ["#0d6efd", "#198754", "#ffc107", "#dc3545"]
            }]
        }
    });
</script>
