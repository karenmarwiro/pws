<?php

namespace App\Core\Controllers;

use App\Core\Controllers\AdminController;
use App\Models\SettingsModel;

class Settings extends AdminController
{
    protected $settingsModel;

    public function __construct()
    {
        $this->settingsModel = new \App\Models\SettingsModel();
    }

    public function index()
    {
        // Get all settings with 'App' class
        $settings = $this->settingsModel->getAllSettings('App');
        
        // Set default values if not exists
        $defaults = [
            'site_name' => 'PWS Prototype',
            'site_url' => 'https://example.com',
            'admin_email' => 'admin@example.com',
            'timezone' => 'UTC',
            'language' => 'en_US',
            'theme' => 'default',
            'sidebar_style' => 'expanded',
            'color_scheme' => 'light',
            'email_notifications' => true,
            'browser_notifications' => false,
            'desktop_notifications' => false,
            'notification_sound' => 'default'
        ];

        // Merge with saved settings
        $data = [
            'title' => 'System Settings',
            'settings' => array_merge($defaults, $settings)
        ];

        return $this->coreView('settings', $data);
    }

    /**
     * Save settings from the form
     */
    public function save()
    {
        // Check if this is an AJAX request
        if ($this->request->isAJAX()) {
            $response = [
                'success' => false,
                'message' => 'Invalid request',
                'data' => []
            ];

            // Get the raw input and decode it
            $input = $this->request->getJSON(true);
            
            // Remove CSRF token from input
            unset($input['csrf_test_name']);
            
            // Define setting groups
            $groups = [
                'general' => ['site_name', 'site_url', 'admin_email', 'timezone', 'language'],
                'appearance' => ['theme', 'sidebar_style', 'color_scheme', 'logo'],
                'notifications' => ['email_notifications', 'browser_notifications', 'desktop_notifications', 'notification_sound']
            ];

            try {
                // Save settings
                foreach ($input as $key => $value) {
                    $group = 'general';
                    
                    // Determine the group
                    foreach ($groups as $groupName => $fields) {
                        if (in_array($key, $fields)) {
                            $group = $groupName;
                            break;
                        }
                    }
                    
                    // Handle checkboxes
                    if (in_array($key, ['email_notifications', 'browser_notifications', 'desktop_notifications'])) {
                        $value = (bool) $value;
                    }
                    
                    // Handle file uploads
                    if ($key === 'logo' && isset($_FILES['logo'])) {
                        $file = $this->handleFileUpload('logo');
                        if ($file) {
                            $this->settingsModel->setSetting('logo', $file, 'App', 'string', $group);
                        }
                        continue;
                    }
                    
                    // Save the setting with proper type
                    $type = null;
                    if (is_bool($value)) {
                        $type = 'bool';
                    } elseif (is_numeric($value)) {
                        $type = is_float($value) ? 'float' : 'int';
                    }
                    
                    $this->settingsModel->setSetting($key, $value, 'App', $type, $group);
                }
                
                // Update the session with the new settings
                $this->updateSessionSettings();
                
                $response = [
                    'success' => true,
                    'message' => 'Settings saved successfully',
                    'data' => $input
                ];
                
            } catch (\Exception $e) {
                log_message('error', 'Error saving settings: ' . $e->getMessage());
                $response['message'] = 'Error saving settings: ' . $e->getMessage();
            }

            return $this->response->setJSON($response);
        }

        // If not AJAX, redirect back to settings page
        return redirect()->to('/settings');
    }
    
    /**
     * Handle file uploads
     */
    protected function handleFileUpload($fieldName)
    {
        $file = $this->request->getFile($fieldName);
        
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $uploadPath = WRITEPATH . 'uploads/settings/';
            
            // Create directory if it doesn't exist
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            
            if ($file->move($uploadPath, $newName)) {
                return 'uploads/settings/' . $newName;
            }
        }
        
        return null;
    }
    
    /**
     * Update session with current settings
     */
    protected function updateSessionSettings()
    {
        $settings = $this->settingsModel->getAllSettings('App');
        session()->set('settings', $settings);
    }
}
