<?php

namespace App\Core\Controllers;

use CodeIgniter\Controller;

class BaseController extends Controller
{
    protected $data = [];
    
    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        
        // Load helpers
        helper(['url', 'form']);
        
        // Set default layout
        $this->data['siteName'] = 'PWS';
    }
}
