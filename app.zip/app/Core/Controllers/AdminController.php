<?php

namespace App\Core\Controllers;

use App\Controllers\BaseController;

class AdminController extends BaseController
{
    public function dashboard()
    {
        $data = [
            'title'    => 'Admin Dashboard',
            'username' => 'AdminUser',
        ];

        // Load the Core dashboard view using the helper from BaseController
        return $this->coreView('dashboard', $data);
    }
}
