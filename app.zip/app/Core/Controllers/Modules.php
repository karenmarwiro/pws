<?php

namespace App\Core\Controllers;

use App\Core\Controllers\AdminController;
use CodeIgniter\API\ResponseTrait;

class Modules extends AdminController
{
    use ResponseTrait;
    public function add()
    {
        $data = [
            'title' => 'Add New Module',
        ];

        return $this->coreView('Layouts/Modules/add', $data);
    }

    public function index()
    {
        $moduleModel = new \App\Models\ModuleModel();
        
        // Ensure core modules exist
        $this->ensureCoreModulesExist();
        
        // Get all modules, ordered by is_core (core modules first) and then by name
        $modules = $moduleModel->orderBy('is_core', 'DESC')
                              ->orderBy('name', 'ASC')
                              ->findAll();
        
        $data = [
            'title' => 'Modules Management',
            'modules' => $modules
        ];

        return $this->coreView('Layouts/Modules/index', $data);
    }
    
    /**
     * Ensure all core modules exist in the database
     */
    protected function ensureCoreModulesExist()
    {
        $moduleModel = new \App\Models\ModuleModel();
        $coreModules = [
            [
                'name' => 'Settings',
                'description' => 'System configuration and preferences',
                'version' => '1.0.0',
                'is_active' => true,
                'is_core' => true,
                'icon' => 'fas fa-cog'
            ],
            [
                'name' => 'Modules',
                'description' => 'Manage system modules',
                'version' => '1.0.0',
                'is_active' => true,
                'is_core' => true,
                'icon' => 'fas fa-puzzle-piece'
            ],
            [
                'name' => 'RBAC',
                'description' => 'Role-Based Access Control',
                'version' => '1.0.0',
                'is_active' => true,
                'is_core' => true,
                'icon' => 'fas fa-user-shield'
            ]
        ];
        
        // Get all current core modules
        $currentCoreModules = $moduleModel->where('is_core', 1)->findAll();
        $currentCoreModuleNames = array_column($currentCoreModules, 'name');
        
        // Process each core module
        foreach ($coreModules as $module) {
            $exists = array_search($module['name'], $currentCoreModuleNames) !== false;
            
            if (!$exists) {
                // Insert new core module
                $moduleModel->insert($module);
            } else {
                // Update existing module to ensure it's marked as core
                $existingModule = $moduleModel->where('name', $module['name'])->first();
                if ($existingModule && !$existingModule['is_core']) {
                    $moduleModel->update($existingModule['id'], ['is_core' => true]);
                }
            }
        }
        
        // Clean up any non-essential core modules
        $essentialNames = array_column($coreModules, 'name');
        foreach ($currentCoreModules as $existingModule) {
            if (!in_array($existingModule['name'], $essentialNames)) {
                $moduleModel->update($existingModule['id'], ['is_core' => false]);
            }
        }
    }

    public function upload()
    {
        // Check if file was uploaded
        if (empty($_FILES['module_zip'])) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'No file was uploaded.'
            ]);
        }

        $file = $_FILES['module_zip'];
        $uploadPath = ROOTPATH . 'modules/';
        
        // Create modules directory if it doesn't exist
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }

        // Validate file type - only allow zip files
        $allowedTypes = ['application/zip', 'application/x-zip-compressed'];
        $fileType = $file['type'];
        // Generate a unique directory name based on the zip filename
        $moduleName = pathinfo($file['name'], PATHINFO_FILENAME);
        $moduleDir = $uploadPath . $moduleName;
        
        // If directory exists, add a suffix
        $counter = 1;
        $originalName = $moduleName;
        while (is_dir($moduleDir)) {
            $moduleName = $originalName . '_' . $counter;
            $moduleDir = $uploadPath . $moduleName;
            $counter++;
        }
        
        mkdir($moduleDir, 0777, true);

        // Move uploaded file
        $zipPath = $moduleDir . '.zip';
        if (!move_uploaded_file($file['tmp_name'], $zipPath)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Failed to save uploaded file.'
            ]);
        }

        // Extract the zip file
        $zip = new \ZipArchive();
        if ($zip->open($zipPath) === TRUE) {
            $zip->extractTo($moduleDir);
            $zip->close();
            
            // Remove the zip file after extraction
            unlink($zipPath);
            
            // Check if we need to move files up one level (if zip contains a single folder)
            $files = scandir($moduleDir);
            $validDirs = array_filter($files, function($item) use ($moduleDir) {
                return is_dir($moduleDir . '/' . $item) && !in_array($item, ['.', '..']);
            });
            
            // If there's only one directory and it's not a required directory, move its contents up
            if (count($validDirs) === 1) {
                $firstDir = $moduleDir . '/' . reset($validDirs);
                $this->moveContentsUp($firstDir, $moduleDir);
                rmdir($firstDir); // Remove the now empty directory
            }
            
            // Check for required directories
            $requiredDirs = ['Controllers', 'Views'];
            $missingDirs = [];
            
            foreach ($requiredDirs as $dir) {
                if (!is_dir($moduleDir . '/' . $dir)) {
                    $missingDirs[] = $dir;
                }
            }
            
            if (!empty($missingDirs)) {
                $this->rrmdir($moduleDir);
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Module is missing required directories: ' . implode(', ', $missingDirs)
                ]);
            }
            
            // Generate namespace from module name (convert to StudlyCase)
            $namespace = 'App\\Modules\\' . $this->toStudlyCase($moduleName);
            
            // Save module to database
            $moduleModel = new \App\Models\ModuleModel();
            
            $moduleData = [
                'name'        => $this->toTitleCase(str_replace('_', ' ', $moduleName)),
                'description' => 'Custom module: ' . $moduleName,
                'version'     => '1.0.0',
                // 'namespace'   => $namespace,  // Temporarily removed
                // 'path'        => str_replace(ROOTPATH, '', $moduleDir),  // Temporarily removed
                'is_active'   => 0,
                'is_core'     => 0,
                'icon'        => 'fas fa-puzzle-piece',
                'created_at'  => date('Y-m-d H:i:s')
            ];

            if ($moduleModel->save($moduleData)) {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'Module installed successfully!',
                    'redirect' => site_url('modules')
                ]);
            } else {
                $this->rrmdir($moduleDir);
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Failed to save module to database.'
                ]);
            }
        } else {
            $this->rrmdir($moduleDir);
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Failed to extract module files.'
            ]);
        }
    }

    /**
     * Recursively remove a directory
     */
    private function rrmdir($dir)
    {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (is_dir($dir . "/" . $object) && !is_link($dir . "/" . $object)) {
                        $this->rrmdir($dir . "/" . $object);
                    } else {
                        unlink($dir . "/" . $object);
                    }
                }
            }
            rmdir($dir);
        }
    }
    
    /**
     * Convert string to StudlyCase
     */
    private function toStudlyCase($string)
    {
        return str_replace(' ', '', ucwords(str_replace(['_', '-'], ' ', $string)));
    }
    
    /**
     * Convert string to Title Case
     */
    private function toTitleCase($string)
    {
        return ucwords(str_replace(['_', '-'], ' ', $string));
    }
    
    /**
     * Move all files and directories from one directory to another
     */
    private function moveContentsUp($source, $destination)
    {
        $files = scandir($source);
        
        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                $srcPath = $source . '/' . $file;
                $destPath = $destination . '/' . $file;
                
                if (is_dir($srcPath)) {
                    // If directory exists in destination, merge them
                    if (is_dir($destPath)) {
                        $this->moveContentsUp($srcPath, $destPath);
                        rmdir($srcPath);
                    } else {
                        rename($srcPath, $destPath);
                    }
                } else {
                    rename($srcPath, $destPath);
                }
            }
        }
    }

    public function edit($id)
    {
        // Sample module data - replace with your actual data fetching
        $modules = [
            1 => [
                'id' => 1,
                'name' => 'Authentication',
                'description' => 'User authentication and authorization',
                'version' => '1.0.0',
                'is_active' => true,
                'is_core' => true,
                'icon' => 'fas fa-lock',
                'author' => 'System',
                'namespace' => 'App\\Modules\\Auth',
                'order' => 1,
                'settings' => ['login_attempts' => 5, 'session_timeout' => 3600],
                'created_at' => '2024-01-15 10:00:00',
                'updated_at' => '2024-01-20 14:30:00'
            ],
            2 => [
                'id' => 2,
                'name' => 'User Management',
                'description' => 'Manage system users and roles',
                'version' => '1.2.0',
                'is_active' => true,
                'is_core' => false,
                'icon' => 'fas fa-users',
                'author' => 'Admin',
                'namespace' => 'App\\Modules\\Users',
                'order' => 2,
                'settings' => ['max_users' => 100, 'default_role' => 'user'],
                'created_at' => '2024-02-01 09:15:00',
                'updated_at' => '2024-02-10 16:45:00'
            ]
        ];

        if (!isset($modules[$id])) {
            return redirect()->to('/modules')->with('error', 'Module not found');
        }

        $data = [
            'title' => 'Edit Module',
            'module' => $modules[$id]
        ];

        return view('modules/edit', $data);
    }

    public function update($id)
    {
        // Validation rules
        $rules = [
            'name' => 'required|min_length[3]|max_length[100]',
            'version' => 'required|min_length[1]|max_length[20]',
            'description' => 'required|min_length[10]|max_length[500]',
            'author' => 'max_length[100]',
            'icon' => 'max_length[50]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Process the update here
        $data = [
            'name' => $this->request->getPost('name'),
            'version' => $this->request->getPost('version'),
            'description' => $this->request->getPost('description'),
            'author' => $this->request->getPost('author'),
            'icon' => $this->request->getPost('icon'),
            'namespace' => $this->request->getPost('namespace'),
            'order' => $this->request->getPost('order'),
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
            'settings' => json_decode($this->request->getPost('settings'), true) ?? [],
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Save to database here
        // $moduleModel->update($id, $data);

        return redirect()->to('/modules')->with('success', 'Module updated successfully');
    }

    public function delete($id)
    {
        // Check if module exists and is not core
        // Delete module logic here

        return redirect()->to('/modules')->with('success', 'Module deleted successfully');
    }

    /**
     * Seed initial modules if none exist
     */
    protected function seedInitialModules()
    {
        $moduleModel = new \App\Models\ModuleModel();
        
        // Define core modules - Only essential system modules
        $coreModules = [
            [
                'name' => 'Settings',
                'description' => 'System configuration and preferences',
                'version' => '1.0.0',
                'is_active' => true,
                'is_core' => true,
                'icon' => 'fas fa-cog'
            ],
            [
                'name' => 'Modules',
                'description' => 'Manage system modules',
                'version' => '1.0.0',
                'is_active' => true,
                'is_core' => true,
                'icon' => 'fas fa-puzzle-piece'
            ],
            [
                'name' => 'RBAC',
                'description' => 'Role-Based Access Control',
                'version' => '1.0.0',
                'is_active' => true,
                'is_core' => true,
                'icon' => 'fas fa-user-shield'
            ]
        ];
        
        // Only seed core modules
        foreach ($coreModules as $module) {
            // Check if module already exists
            $exists = $moduleModel->where('name', $module['name'])->first();
            if (!$exists) {
                $moduleModel->insert($module);
            } else if (!$exists['is_core']) {
                // Update existing module to be a core module
                $moduleModel->update($exists['id'], ['is_core' => true]);
            }
        }
    }
    
    /**
     * Enable a module
     */
    public function enableModule()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(405)->setJSON([
                'success' => false,
                'message' => 'Method not allowed'
            ]);
        }

        $moduleName = $this->request->getJSON(true)['module'] ?? null;
        if (strpos($moduleName, '_') !== false) {
            // Convert from slug format (notifications_5) to display format (Notifications 5)
            $moduleName = ucwords(str_replace('_', ' ', $moduleName));
        }
        
        $moduleModel = new \App\Models\ModuleModel();
        $module = $moduleModel->where('name', $moduleName)->first();
        
        if (!$module) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Module not found'
            ]);
        }
        
        // Update the status
        $moduleModel->update($module['id'], ['is_active' => 1]);
        
        return $this->response->setJSON([
            'success' => true,
            'message' => 'Module enabled successfully',
            'data' => [
                'id' => $module['id'],
                'is_active' => true
            ]
        ]);
    }
    
    /**
     * Disable a module
     */
    public function disableModule()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(405)->setJSON([
                'success' => false,
                'message' => 'Method not allowed'
            ]);
        }

        $moduleName = $this->request->getJSON(true)['module'] ?? null;
        if (strpos($moduleName, '_') !== false) {
            // Convert from slug format (notifications_5) to display format (Notifications 5)
            $moduleName = ucwords(str_replace('_', ' ', $moduleName));
        }
        
        $moduleModel = new \App\Models\ModuleModel();
        $module = $moduleModel->where('name', $moduleName)->first();
        
        if (!$module) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Module not found'
            ]);
        }
        
        // Prevent disabling core modules
        if ($module['is_core']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Cannot disable core modules'
            ])->setStatusCode(400);
        }
        
        // Update the status
        $moduleModel->update($module['id'], ['is_active' => 0]);
        
        return $this->response->setJSON([
            'success' => true,
            'message' => 'Module disabled successfully',
            'data' => [
                'id' => $module['id'],
                'is_active' => false
            ]
        ]);
    }
    
    /**
     * Toggle module active status
     */
    public function toggle($id = null)
    {
        // Only allow AJAX requests
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(405)->setJSON([
                'success' => false,
                'message' => 'Method not allowed'
            ]);
        }

        $moduleModel = new \App\Models\ModuleModel();
        $module = $moduleModel->find($id);
        
        if (!$module) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Module not found'
            ]);
        }
        
        // Get the requested action from the request body
        $request = $this->request->getJSON(true) ?? [];
        $enable = $request['enable'] ?? !$module['is_active'];
        
        // Prevent deactivating core modules
        if ($module['is_core'] && $enable === false) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Cannot deactivate core modules'
            ])->setStatusCode(400);
        }
        
        // Update the status
        $moduleModel->update($id, ['is_active' => $enable ? 1 : 0]);
        
        // Get the updated module
        $updatedModule = $moduleModel->find($id);
        
        return $this->response->setJSON([
            'success' => true,
            'message' => 'Module ' . ($enable ? 'activated' : 'deactivated') . ' successfully',
            'data' => [
                'id' => $id,
                'is_active' => (bool)$updatedModule['is_active']
            ]
        ]);
    }
    
        // This return statement was unreachable and caused a syntax error
        // as it was outside any method
}
