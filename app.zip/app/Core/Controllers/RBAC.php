<?php

namespace App\Core\Controllers;

use App\Core\Controllers\BaseController;
use App\Core\Services\RoleAccessServices;

class RBAC extends BaseController
{
    protected $roleAccess;

    public function __construct()
    {
        $this->roleAccess = new RoleAccessServices();
        helper(['form']);
    }

    /**
     * RBAC Dashboard
     */
    public function index()
    {
        if (!auth()->user()->can('rbac.manage')) {
            return redirect()->to('/')->with('error', 'Unauthorized access');
        }

        $data = [
            'title' => 'RBAC Management',
            'roles' => $this->roleAccess->getAllRoles(),
            'users' => model('UserModel')->findAll()
        ];

        return view('rbac', $data);
    }

    /**
     * Manage User Roles
     */
    public function manageUserRoles($userId = null)
    {
        if (!auth()->user()->can('rbac.manage')) {
            return redirect()->to('/')->with('error', 'Unauthorized access');
        }

        $userId = $userId ?: $this->request->getGet('user_id');
        
        if (!$userId) {
            return redirect()->to('/rbac')->with('error', 'User ID required');
        }

        $userModel = model('UserModel');
        $user = $userModel->find($userId);
        
        if (!$user) {
            return redirect()->to('/rbac')->with('error', 'User not found');
        }

        if ($this->request->getMethod() === 'post') {
            return $this->updateUserRoles($userId);
        }

        $data = [
            'title' => 'Manage Roles for ' . $user->username,
            'user' => $user,
            'allRoles' => $this->roleAccess->getAllRoles(),
            'userRoles' => $user->getGroups()
        ];

        return view('rbac/manage_user_roles', $data);
    }

    /**
     * Update User Roles
     */
    private function updateUserRoles($userId)
    {
        $selectedRoles = $this->request->getPost('roles') ?: [];

        // Get current user roles
        $user = model('UserModel')->find($userId);
        $currentRoles = $user->getGroups();

        // Remove roles that were deselected
        foreach ($currentRoles as $role) {
            if (!in_array($role, $selectedRoles)) {
                $this->roleAccess->removeRole($userId, $role);
            }
        }

        // Add newly selected roles
        foreach ($selectedRoles as $role) {
            if (!in_array($role, $currentRoles)) {
                $this->roleAccess->assignRole($userId, $role);
            }
        }

        return redirect()->back()->with('success', 'User roles updated successfully');
    }

    /**
     * Manage Role Permissions
     */
    public function manageRolePermissions($role = null)
    {
        if (!auth()->user()->can('rbac.manage')) {
            return redirect()->to('/')->with('error', 'Unauthorized access');
        }

        $role = $role ?: $this->request->getGet('role');
        
        if (!$role) {
            return redirect()->to('/rbac')->with('error', 'Role name required');
        }

        if ($this->request->getMethod() === 'post') {
            return $this->updateRolePermissions($role);
        }

        $data = [
            'title' => 'Manage Permissions for ' . $role,
            'role' => $role,
            'rolePermissions' => $this->roleAccess->getRolePermissions($role)
        ];

        return view('rbac/manage_role_permissions', $data);
    }

    /**
     * Update Role Permissions
     */
    private function updateRolePermissions($role)
    {
        $permissions = $this->request->getPost('permissions') ?: [];
        $currentPermissions = $this->roleAccess->getRolePermissions($role);

        // Remove permissions that were deselected
        foreach ($currentPermissions as $permission) {
            if (!in_array($permission, $permissions)) {
                $this->roleAccess->removePermissionFromRole($role, $permission);
            }
        }

        // Add newly selected permissions
        foreach ($permissions as $permission) {
            if (!in_array($permission, $currentPermissions)) {
                $this->roleAccess->addPermissionToRole($role, $permission);
            }
        }

        return redirect()->back()->with('success', 'Role permissions updated successfully');
    }

    /**
     * View Users by Role
     */
    public function usersByRole($role)
    {
        if (!auth()->user()->can('rbac.manage')) {
            return redirect()->to('/')->with('error', 'Unauthorized access');
        }

        $users = $this->roleAccess->getUsersByRole($role);

        $data = [
            'title' => 'Users with ' . $role . ' role',
            'users' => $users,
            'role' => $role
        ];

        return view('rbac/users_by_role', $data);
    }

    /**
     * Quick Role Assignment Methods
     */
    public function assignRole($userId, $role)
    {
        if (!auth()->user()->can('rbac.manage')) {
            return redirect()->to('/')->with('error', 'Unauthorized access');
        }

        try {
            $this->roleAccess->assignRole($userId, $role);
            return redirect()->back()->with('success', "{$role} role assigned successfully");
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function removeRole($userId, $role)
    {
        if (!auth()->user()->can('rbac.manage')) {
            return redirect()->to('/')->with('error', 'Unauthorized access');
        }

        try {
            $this->roleAccess->removeRole($userId, $role);
            return redirect()->back()->with('success', "{$role} role removed successfully");
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}