<?php

namespace App\Core\Services;

use CodeIgniter\Shield\Authorization\AuthorizationException;
use CodeIgniter\Shield\Entities\User;

class RoleAccessServices
{
    protected $authorization;
    protected $userModel;
    protected $groupModel;
    protected $permissionModel;

    public function __construct()
    {
        $this->authorization = service('authorization');
        $this->userModel = model('UserModel');
        $this->groupModel = model('GroupModel');
        $this->permissionModel = model('PermissionModel');
    }

    /**
     * Get all available roles
     */
    public function getAllRoles(): array
    {
        return $this->groupModel->findAll();
    }

    /**
     * Check if user has a specific role
     */
    public function hasRole(int $userId, string $role): bool
    {
        $user = $this->userModel->find($userId);
        return $user->inGroup($role);
    }

    /**
     * Assign a role to a user
     */
    public function assignRole(int $userId, string $role): bool
    {
        $user = $this->userModel->find($userId);
        
        if (!$user) {
            throw new \RuntimeException('User not found');
        }

        $user->addGroup($role);
        return $this->userModel->save($user);
    }

    /**
     * Remove a role from a user
     */
    public function removeRole(int $userId, string $role): bool
    {
        $user = $this->userModel->find($userId);
        
        if (!$user) {
            throw new \RuntimeException('User not found');
        }

        $user->removeGroup($role);
        return $this->userModel->save($user);
    }

    /**
     * Check if user has permission
     */
    public function hasPermission(int $userId, string $permission): bool
    {
        $user = $this->userModel->find($userId);
        return $user->can($permission);
    }

    /**
     * Get all permissions for a specific role
     */
    public function getRolePermissions(string $role): array
    {
        $group = $this->groupModel->where('name', $role)->first();
        return $group ? $group->permissions : [];
    }

    /**
     * Add permission to a role
     */
    public function addPermissionToRole(string $role, string $permission): bool
    {
        $group = $this->groupModel->where('name', $role)->first();
        
        if (!$group) {
            throw new \RuntimeException('Role not found');
        }

        $permissions = $group->permissions;
        if (!in_array($permission, $permissions)) {
            $permissions[] = $permission;
            $group->permissions = $permissions;
            return $this->groupModel->save($group);
        }

        return true;
    }

    /**
     * Remove permission from a role
     */
    public function removePermissionFromRole(string $role, string $permission): bool
    {
        $group = $this->groupModel->where('name', $role)->first();
        
        if (!$group) {
            throw new \RuntimeException('Role not found');
        }

        $permissions = $group->permissions;
        $key = array_search($permission, $permissions);
        
        if ($key !== false) {
            unset($permissions[$key]);
            $group->permissions = array_values($permissions);
            return $this->groupModel->save($group);
        }

        return true;
    }

    /**
     * Get all users with a specific role
     */
    public function getUsersByRole(string $role): array
    {
        return $this->userModel->whereIn('id', function($builder) use ($role) {
            return $builder->select('user_id')
                         ->from('auth_groups_users')
                         ->where('group', $role);
        })->findAll();
    }
}