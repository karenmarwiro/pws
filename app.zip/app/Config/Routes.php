<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
service('auth')->routes($routes);
$routes->get('auth/redirect/github', 'GithubAuthController::redirect');
$routes->get('auth/callback/github', 'GithubAuthController::callback');


// Load Core routes
require APPPATH . 'Core/Config/Routes.php';

// Autoload Core module routes
$corePath = APPPATH . 'Modules/';   // points to app/pws/Core/
$modules  = scandir($corePath);

foreach ($modules as $module) {
    if ($module === '.' || $module === '..') continue;

    $routePath = $corePath . $module . '/Config/Routes.php';
    if (file_exists($routePath)) {
        require $routePath;
    }
}

