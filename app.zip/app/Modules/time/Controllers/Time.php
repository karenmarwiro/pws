<?php

namespace App\Modules\Time\Controllers;

use App\Core\Controllers\AdminController;

class Time extends AdminController
{
    public function index()
    {
        $data = [
            'title' => 'Products',
            'items' => [
                ['name' => 'Product A', 'price' => '$10', 'status' => 'Active'],
                ['name' => 'Product B', 'price' => '$15', 'status' => 'Inactive'],
                ['name' => 'Product C', 'price' => '$20', 'status' => 'Active'],
            ],
        ];

        return $this->moduleView('time', 'index', $data);
    }
}
