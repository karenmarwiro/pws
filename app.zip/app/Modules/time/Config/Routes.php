<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Base path for Products module
$routes->group('time', ['namespace' => 'App\Modules\Time\Controllers'], function($routes) {

    // List all products
    $routes->get('/', 'Time::index');

});
