<!-- Header -->
<?php include $coreViewPath . 'Partials/header.php'; ?>

<!-- Sidebar/Menu -->
<?php include $coreViewPath . 'Partials/menu.php'; ?>

notificatios here 

<?php include $coreViewPath . 'Partials/footer.php'; ?>
