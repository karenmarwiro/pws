<!-- Header -->
<?php include $coreViewPath . 'Partials/header.php'; ?>

<!-- Sidebar/Menu -->
<?php include $coreViewPath . 'Partials/menu.php'; ?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <h1><?= esc($title) ?></h1>
        </div>
    </section>

    
</div>

<!-- footer -->
<?php include $coreViewPath . 'Partials/footer.php'; ?>
