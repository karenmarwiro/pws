<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Base path for comments module
$routes->group('reports', ['namespace' => 'App\Modules\Reports\Controllers'], function($routes) {

    
    $routes->get('/', 'reports::index');

});
